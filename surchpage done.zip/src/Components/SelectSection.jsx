
import {
  Box,
  Grid,
  Typography,
  TextField,
} from "@mui/material";
import React from "react";
import { makeStyles } from "tss-react/mui";
import CommonSelect from "./Common/CommonSelect";
import Slider from "@mui/material/Slider";
import { Form, Formik } from "formik";
import { Animated } from "react-animated-css";
import StyledButton1 from "./Common/StyledButton1";
import SelectStartAdornment from "./Common/SelectStartAdornment";

const useStyles = makeStyles()((theme) => {
  return {
    selectMain: {
      padding: "10px 0px 30px 0px",
      [theme.breakpoints.down("laptop")]: {
        padding: "0rem 3rem 2rem 3rem",
      },
      [theme.breakpoints.down("mobile")]: {
        padding: "0rem 1rem 2rem 1rem",
      },
      "div div form div": {
        width: "100%",
      },
      "div div a": {
        height: "45px !important",
        [theme.breakpoints.down("tab")]: {
          marginTop: "10px",
        },
      },
    },
    selectStack: {
      flexWrap: "nowrap",
      [theme.breakpoints.down("tab")]: {
        flexWrap: "wrap",
      },
    },
    pricerange: {
      fontFamily: "League Spartan",
      fontStyle: "normal",
      fontWeight: 400,
      fontSize: "18px",
      letterSpacing: "0.03em",
      color: "black",
      marginTop: "-10px",
      [theme.breakpoints.down("mobile")]: {
        marginTop: "10px",
      },
    },
    priceRangeMain: {
      display: "flex",
    },
    priceRangeMin: {
      fontFamily: "League Spartan",
      fontStyle: "normal",
      fontWeight: 400,
      fontSize: "15px",
      letterSpacing: "0.03em",
      color: "#818183",
    },
    priceRangeCenter: {
      marginLeft: "5px",
      marginRight: "5px",
      fontFamily: "League Spartan",
      fontStyle: "normal",
      fontWeight: 400,
      fontSize: "15px",
      letterSpacing: "0.03em",
      color: "#818183",
    },
    priceRangeMax: {
      fontFamily: "League Spartan",
      fontStyle: "normal",
      fontWeight: 400,
      fontSize: "15px",
      letterSpacing: "0.03em",
      color: "#818183",
    },
    textField: {
      div: {
        width: "100%",
        [theme.breakpoints.down("tab")]: {
          marginTop: "11px",
        },
      },
      input: {
        padding: "10.5px !important",
      },
      [`& fieldset`]: {
        borderRadius: 0,
      },
      // 'label': {
      //   top: "-5px",
      // },
      label: {
        fontFamily: "League Spartan",
        fontStyle: "normal",
        fontWeight: 400,
        fontSize: "17px",
        color: "#7E7F84",
        top: "-5px",
        [theme.breakpoints.down("tab")]: {
          top: "4px",
        },
      },
    },
    category: {
      [theme.breakpoints.down("tab")]: {
        marginTop: '10px'
      },
    }
  };
});
const keyWord = [
  {
    name: "High to Low",
    value: "htl",
  },
  {
    name: "Low to High",
    value: "lth",
  },
  {
    name: "A-Z",
    value: "atz",
  },
  {
    name: "Z-A",
    value: "zta",
  },
];
// const options = [{name:'Option 1'}, {'Option 2'}];
const SelectSection = (props) => {
  console.log("props", props);
  const { classes } = useStyles();

  const handleChange2 = (event, newValue) => {
    console.log(newValue, "newValue");
    props?.setValueRange(newValue);
  };
  const initialValues = {
    Keywords: "",
  };
  return (
    <Animated animationIn="fadeIn" animationOut="fadeOut" isVisible={true}>
      <Box
        className={classes.selectMain}
        sx={(theme) => ({
          margin: props?.m,
          borderBottom: props?.b,
          [theme.breakpoints.down("desktop")]: {
            margin: props?.desktopm,
          },
          [theme.breakpoints.down("laptop")]: {
            margin: props?.laptopm,
          },
        })}
      >
        <Grid
          container
          spacing={{ xSmall: 1, iph: 2, laptop: 2 }}
          columns={{ xSmall: 4, iph: 4, mobile: 4, stab: 12, laptop: 16 }}
        >
          <Grid item xSmall={4} iph={4} mobile={2} stab={4} laptop={5.3} xlDesktop={2.6} >
            <Formik initialValues={initialValues}>
              {({ values, setFieldValue }) => (
                <Form>
                  <TextField
                    className={classes.textField}
                    id="Keywords"
                    label="Keywords"
                    sx={(theme) => ({
                      marginTop:"2px",
                      [theme.breakpoints.down("tab")]: {
                        marginTop: "10px",
                      },
                      [theme.breakpoints.down("mobile")]: {
                        width: "100%",
                      },
                    })}
                  />
                </Form>
              )}
            </Formik>
          </Grid>
          <Grid className={classes.category} item xSmall={4} iph={4} mobile={2} stab={4} laptop={5.3} xlDesktop={2.6}>
            <CommonSelect
              className={classes.textField}
              title="Category"
              name="category"
              options={props?.categoryListData}
              value={props?.category}
              inputValue={props?.inputValue}
              setValue={props?.setCategory}
              setInputValue={props?.setInputValue}
            />
          </Grid>
          <Grid className={classes.category} item xSmall={4} iph={4} mobile={2} stab={4} laptop={5.3} xlDesktop={2.6}>
            <CommonSelect
              className={classes.textField}
              title="Sub category"
              name="Sub_category"
              
              subCateApi={props?.subCateApi}
              options={props?.subcategoryListData}
              value={props?.value2}
              inputValue={props?.inputValue2}
              setValue={props?.setValue2}
              setInputValue={props?.setInputValue2}
            />
          </Grid>
          <Grid item xSmall={4} iph={4} mobile={2} stab={4} laptop={5.3} xlDesktop={2.6}>
            <Typography variant="h6" className={classes.pricerange}>
              Price range
            </Typography>
            <Slider
              min={+props?.minPrice}
              max={+props?.maxPrice}
              getAriaLabel={() => "Temperature range"}
              value={props?.valueRange}
              onChange={handleChange2}
              valueLabelDisplay="auto"
            />
            <Box
              item
              xSmall={4}
              iph={4}
              mobile={2}
              stab={4}
              laptop={5.3}
              xlDesktop={2.3}
              className={classes.priceRangeMain}
            >
              <Typography variant="h6" className={classes.priceRangeMin}>
                {props?.valueRange[0]}
              </Typography>
              <Typography variant="h6" className={classes.priceRangeCenter}>
                -
              </Typography>
              <Typography variant="h6" className={classes.priceRangeMax}>
                {props?.valueRange[1]}
              </Typography>
            </Box>
          </Grid>
          <Grid
            item
            xSmall={4}
            iph={4}
            mobile={2}
            stab={4}
            laptop={5.3}
            xlDesktop={2.6}
          >

            <SelectStartAdornment
              className={classes.textField}
              inputAdornment="Sort By :"
              options={keyWord}
              value={props?.shortBy}
              inputValue={props?.inputValue2}
              setValue={props?.setShortBy}
              setInputValue={props?.setInputValue2}
            />
          </Grid>
          <Grid
            item
            xSmall={4}
            iph={4}
            mobile={2}
            stab={4}
            laptop={5.3}
            xlDesktop={2.6}
          >
            <StyledButton1 text="search" />
          </Grid>
        </Grid>
      </Box>
    </Animated>
  );
};
export default SelectSection;
