import React from "react";
import { makeStyles } from "tss-react/mui";
import Paper from "@mui/material/Paper";
import InputBase from "@mui/material/InputBase";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import { Box } from "@mui/material";
import coupon from "../../Assests/images/coupon.png";

const useStyles = makeStyles()((theme) => {
  return {
    apply: {
      border: "1px solid #CACACA",
      display: "flex",
      alignItems: "center",
      padding: "17px 20px",
      width: "556px",
      height: "58px",
      [theme.breakpoints.down("tab")]: {
        width: "542px",
      },
      [theme.breakpoints.down("mobile")]: {
        width: "448px",
        height: "48px",
        padding: "15px",
      },
      [theme.breakpoints.down("iph")]: {
        width: "326px",
        height: "42px",
      },
      [theme.breakpoints.down("small")]: {
        width: "292px",
      },
    },
    coupimg: {
      width: "24px",
      height: "24px",
      [theme.breakpoints.down("mobile")]: {
        width: "20px",
        height: "20px",
      },
    },
    textPart: {
      fontFamily: "League Spartan",
      fontStyle: "Regular",
      fontWeight: 400,
      fontSize: "18px",
      lineHeight: "17px",
      TextAlign: "Left",
      verticalAlign: "Top",
      letterSpacing: "3%",
      color: "#7E7F84",
      marginLeft: "18px",
      flex: 1,
      [theme.breakpoints.down("mobile")]: {
        fontSize: "16px",
        marginLeft: "12px",
      },
    },
    applybutt: {
      fontFamily: "League Spartan",
      fontStyle: "Regular",
      fontSize: "18px",
      lineHeight: "18px",
      fontWeight: 500,
      TextAlign: "Left",
      verticalAlign: "Top",
      letterSpacing: "7%",
      textTransform: "uppercase",
      color: "#35364F",
      paddingLeft: "23px",
      [theme.breakpoints.down("mobile")]: {
        fontSize: "16px",
        paddingLeft: "15px",
      },
      [theme.breakpoints.down("iph")]: {
        fontSize: "15px",
      },
      "&:hover": {
        color: "#BD3D3D",
      },
    },
  };
});

function ApplyCode() {
  const { classes } = useStyles();
  return (
    <Paper component="form" elevation={0} square className={classes.apply}>
      <IconButton disableRipple sx={{ p: 0 }}>
        <Box component="img" src={coupon} alt="" className={classes.coupimg} />
      </IconButton>
      <InputBase
        className={classes.textPart}
        placeholder="Coupon Code"
        inputProps={{ "aria-label": "Coupon Code" }}
      />
      <Divider sx={{ height: 25, color: "#CACACA" }} orientation="vertical" />
      <IconButton disableRipple className={classes.applybutt} sx={{ p: 0 }}>
        Apply code
      </IconButton>
    </Paper>
  );
}

export default ApplyCode;
