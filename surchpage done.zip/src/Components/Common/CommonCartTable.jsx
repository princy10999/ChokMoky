import * as React from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import { useLocation } from "react-router-dom";
import { makeStyles } from "tss-react/mui";
import girl from "../../Assests/images/order_img2.png";
import { Box } from "@mui/system";
import CloseIcon from "@mui/icons-material/Close";
import { Container, Stack, Tooltip, Typography } from "@mui/material";
import Counter from "./Counter";

const useStyles = makeStyles()((theme) => {
  return {
    containerBox: {
      paddingLeft: "0px",
      paddingRight: "0px",
    },
    tablerow: {
      //   borderBottom: "1px solid #D6D6D6",
      backgroundColor: "#F8F8F8",
    },
    tableHeadName: {
      fontFamily: "League Spartan",
      fontStyle: "normal",
      fontWeight: "400",
      fontSize: "22px",
      lineHeight: "39px",
      padding: "20px 10px 14px 10px",
      border: "none",
      color: "#3D3D47",
      whiteSpace: "nowrap",
      maxWidth: "100%",
      "&:first-child": {
        paddingLeft: "29px",
        width: "37%",
        [theme.breakpoints.down("tab")]: {
          paddingLeft: "15px",
        },
      },
      [theme.breakpoints.down("tab")]: {
        fontSize: "18px",
      },
    },
    productName: {
      fontFamily: "League Spartan",
      fontStyle: "normal",
      fontWeight: "400",
      fontSize: "22px",
      lineHeight: "20.24px",
      border: "none",
      color: "#2F2F2D",
      marginTop: "5px",
      marginBottom: "12px",
      whiteSpace: "nowrap",
      [theme.breakpoints.down("desktop")]: {
        fontSize: "17px",
        lineHeight: "17px",
        whiteSpace: "pre-wrap",
      },
      [theme.breakpoints.down("tab")]: {
        whiteSpace: "nowrap",
      },
    },
    productPrice: {
      fontFamily: "League Spartan",
      fontStyle: "normal",
      fontWeight: "400",
      fontSize: "19px",
      lineHeight: "17.48px",
      color: "#3D3D47",
      whiteSpace: "nowrap",
      [theme.breakpoints.down("desktop")]: {
        fontSize: "18px",
        lineHeight: "18px",
      },
      [theme.breakpoints.down("tab")]: {
        fontSize: "17px",
        lineHeight: "17px",
      },
    },
    orderDate: {
      fontFamily: "League Spartan",
      fontStyle: "normal",
      fontWeight: "400",
      fontSize: "19px",
      lineHeight: "17.48px",
      color: "#3D3D47",
      whiteSpace: "nowrap",
      [theme.breakpoints.down("tab")]: {
        fontSize: "14px",
      },
    },
    prodCont: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
    },
    Img: {
      height: "84px",
      width: "81px",
    },
    dashIco: {
      color: "#858A8C",
      cursor: "pointer",
      "&:hover": {
        color: "#BD3D3D",
      },
    },
  };
});

function createData(name, price,quantity, Subtotal) {
  return { name, price,quantity, Subtotal };
}

const rows = [
  createData("Silver Diamond Waves Ring", "₹300","2", "₹300"),
  createData("Silver Diamond Waves Ring", "₹750","1", "₹750"),
];

export default function ShoppingCartTable() {
  const { classes} = useStyles();
  const location = useLocation();
  return (
    <Container className={classes.containerBox}>
      <TableContainer>
        <Table aria-label="a dense table">
          <TableHead>
            <TableRow className={classes.tablerow}>
              <TableCell className={classes.tableHeadName}>Product</TableCell>
              <TableCell className={classes.tableHeadName} align="center">
                Price
              </TableCell>
              <TableCell className={classes.tableHeadName} align="center">
                Quantity
              </TableCell>
              <TableCell className={classes.tableHeadName} align="center">
                Subtotal
              </TableCell>
              <TableCell className={classes.tableHeadName} align="center">
                Remove
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody sx={{ border: "none", boxShadow: "none" }}>
            {rows.map((row) => (
              <TableRow key={row.name} sx={{ boxShadow: "none" }}>
                <TableCell
                  scope="row"
                  sx={(theme) => ({
                    pl: "29px",
                    [theme.breakpoints.down("tab")]: { pl: "15px" },
                  })}
                >
                  <Stack
                    direction="row"
                    spacing={{ xSmall: 1.9 }}
                    className={classes.imgBox}
                  >
                    <Box
                      component="img"
                      src={girl}
                      alt=""
                      className={classes.Img}
                    />
                    <Box className={classes.prodCont}>
                      <Typography className={classes.productName}>
                        {row.name}
                      </Typography>
                    </Box>
                  </Stack>
                </TableCell>
                <TableCell className={classes.orderDate} align="center">
                  {row.price}
                </TableCell>
                <TableCell className={classes.orderDate} align="center">
                  {location?.pathname === "/cart"?
                  <Counter />
                  :
                  row.quantity
                  }
                </TableCell>
                <TableCell className={classes.orderDate} align="center">
                  {row.Subtotal}
                </TableCell>
                <TableCell>
                  <Stack
                    direction="row"
                    spacing={{ xSmall: 1.9 }}
                    className={classes.imgBox}
                    justifyContent="center"
                  >
                    <Tooltip title="Remove">
                      <CloseIcon className={classes.dashIco} />
                    </Tooltip>
                  </Stack>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Container>
  );
}
