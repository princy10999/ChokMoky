import { Link as RouterLink, useNavigate } from "react-router-dom";
import { Box, Link, Typography, Avatar } from "@mui/material";
import dashboardActive from "../../Assests/images/dashbord_active.svg";
import editActive from "../../Assests/images/edit_active.svg";
import orderActive from "../../Assests/images/clock_active.svg";
import checkCircleActive from "../../Assests/images/check-circle_active.svg";
import wishlistActive from "../../Assests/images/hart_active.svg";
import lockActive from "../../Assests/images/lock_active.svg";
import sideLine from "../../Assests/images/sideLine.png"
import Tester from "../../Assests/images/tester3.png";
import NavSection from "../Common/NavSection";
import { makeStyles } from "tss-react/mui";
import { useAppSelector } from "../../Redux/app/hooks";
import { useDispatch } from "react-redux";
import { isLoader } from "../../Redux/Actions/loaderSlice";
import { userDetails } from "../../Redux/Actions/AuthUser";
import { useEffect } from "react";
import swal from "sweetalert";
import { RxPieChart } from "react-icons/rx";
import { TfiHeart } from "react-icons/tfi";
import { BsPerson } from "react-icons/bs";
import { AiOutlineClockCircle } from "react-icons/ai";
import { FiCheckCircle, FiLock } from "react-icons/fi";
import { TbLogin } from "react-icons/tb";

// ----------------------------------------------------------------------
const useStyles = makeStyles()((theme) => {
  return {
    nanvbox: {
      borderRight: "solid 1.9px #DDDDDD",
      [theme.breakpoints.down("laptop")]: {
        display: "none",
      },
      minWidth: "300px",
    },
    navMainBox: {
      marginTop: "3rem",
      "& .simplebar-content": {
        display: "flex",
        flexDirection: "column",
      },
    },
    avatar: {
      width: "74px",
      height: "74px",
    },
    avatarBox: {
      display: "flex",
      alignItems: "center",
    },
    avatarName: {
      fontFamily: "League Spartan",
      fontSize: "21px",
      lineHeight: "19.32px",
      fontWeight: "500",
      letterSpacing: "3%",
    },
    avatarEmail: {
      fontFamily: "Nunito",
      fontSize: "14px",
      lineHeight: "19.1px",
      fontWeight: "400",
      letterSpacing: "3%",
    },
    imgLine: {
      width: "100%",
    },

  };
});
const account = {
  displayName: "Admin",
  email: "admin@gmail.com",
  photoURL: Tester,
};
// ----------------------------------------------------------------------
export default function SideBar({ isOpenSidebar, onCloseSidebar }) {
  const navigate = useNavigate()
  const logout = () => {
    swal({
      title: "Warning",
      text: "Are you sure you want to logout?",
      icon: "warning",
    }).then((res) => {
      if (res) {
        localStorage.clear();
        navigate("/login");
      }
    });
  };
  const navConfig = [
    {
      title: "Dashboard",
      path: "/dashboard",
      icon: <RxPieChart size={25} />,
      icon2: dashboardActive,
    },
    {
      title: " Edit Profile ",
      path: "/edit-profile",
      icon: <BsPerson size={25} />,
      icon2: editActive,
    },
    {
      title: "Order history",
      path: "/order-history",
      icon: <AiOutlineClockCircle size={25} />,
      icon2: orderActive,
    },
    {
      title: "Order Detail",
      path: "/order-details",
      icon: <FiCheckCircle size={25} />,
      icon2: checkCircleActive,
    },
    {
      title: "wishlist",
      path: "/wishlist",
      icon: <TfiHeart size={25} />,
      icon2: wishlistActive,
    },
    {
      title: "Change password",
      path: "/change-password",
      icon: <FiLock size={25} />,
      icon2: lockActive,
    },
    {
      title: "Logout",
      icon: <TbLogin size={25} />,
      onClick: logout,
    },
  ];
  const dispatch = useDispatch()
  const userDetail = useAppSelector(
    (state) => state?.auth?.isUserDetailsData?.userDetail?.result?.userData
  );
  useEffect(() => {
    dispatch(isLoader(true))
    dispatch(userDetails())
    dispatch(isLoader(false))
  }, []);
  console.log("userDetail", userDetails);
  const { classes } = useStyles();
  const renderContent = (
    <Box className={classes?.navMainBox}>
      <Box sx={{ mb: 1, mx: 2.5 }}>
        <Link
          underline="none"
          component={RouterLink}
          to="#"
          className={classes?.avatarBox}
        >
          <Avatar
            src={
              userDetail?.profile_image
                ? userDetail?.image_path + userDetail?.profile_image
                : account.photoURL
            }
            className={classes?.avatar}
            alt="photoURL"
          />
          <Box sx={{ ml: 2 }}>
            <Typography
              variant="subtitle2"
              sx={{ color: "text.primary" }}
              className={classes?.avatarName}
            >
              {userDetail?.first_name}&nbsp;{userDetail?.last_name}
            </Typography>
            <Typography
              variant="body2"
              sx={{ color: "text.secondary" }}
              className={classes?.avatarEmail}
            >
              {userDetail?.email}
            </Typography>
          </Box>
        </Link>

      </Box>
      <Box>
        <Box
          component="img"
          src={sideLine}
          alt=""
          className={classes.imgLine}
        />
      </Box>
      <NavSection navConfig={navConfig} />
      <Box sx={{ flexGrow: 1 }} />
    </Box>
  );
  return (
    <>
      <Box className={classes?.nanvbox}>{renderContent}</Box>
    </>
  );
}