import { Box, Button, FormHelperText, Typography } from "@mui/material";
import React from "react";
import { Link } from "react-router-dom";
import { makeStyles } from "tss-react/mui";
import EastIcon from "@mui/icons-material/East";
import { useLocation } from "react-router-dom";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";

const useStyles = makeStyles()((theme) => {
  return {
    subtot: {
      display: "flex",
      flexDirection: "column",
    },
    subtotttl: {
      display: "flex",
      justifyContent: "space-between",
      color: "#4E4E56",
      fontSize: "20px",
      fontWeight: 400,
      lineHeight: "39px",
      fontFamily: "League Spartan",
      [`& span`]: {
        color: "#1A1B2F",
        fontSize: "20px",
        fontWeight: 400,
        lineHeight: "39px",
        fontFamily: "League Spartan",
      },
    },
    subtotal: {
      display: "flex",
      justifyContent: "space-between",
      color: "#1A1B2F",
      fontSize: "20px",
      fontWeight: 500,
      lineHeight: "39px",
      padding: "7px 0",
      fontFamily: "League Spartan",
      borderTop: "1px solid rgba(214, 214, 214, 0.4)",
      borderBottom: "1px solid rgba(214, 214, 214, 0.4)",
      [`& span`]: {
        color: "#1A1B2F",
        fontSize: "20px",
        fontWeight: 500,
        lineHeight: "39px",
        fontFamily: "League Spartan",
      },
    },
    checkButt: {
      marginTop: "20px",
    },
    saveButton: {
      padding: "18px 15px 12px 15px",
      backgroundColor: "#141524",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      borderRadius: "0",
      height: "48px",
      width: "100%",
      position: "relative",
      zIndex: "2",
      overflow: "hidden",
      "&:hover": {
        backgroundColor: "#BD3D3D !important",
      },
      "&::before": {
        content: '""',
        opacity: 0,
        position: "absolute",
        transition: "all 0.85s cubic-bezier(0.68, -0.55, 0.265, 1.55)",
        width: "0%",
        height: "100%",
        background: "#BD3D3D",
        zIndex: "-1",
        top: "-50px",
        "-webkit-transform": "rotate(35deg)",
        transform: "rotate(35deg)",
      },
      "&::after": {
        background: "#fff",
        content: '""',
        opacity: 0,
        position: "absolute",
        top: "-50px",
        "-webkit-transform": "rotate(35deg)",
        transform: "rotate(35deg)",
        transition: "all 3s cubic-bezier(0.19, 1, 0.22, 1)",
        height: "20rem",
        width: "8rem",
        left: "-100%",
      },
      "&:hover::before": {
        left: "120%",
        opacity: "0.5",
      },
      "&:hover::after": {
        left: "200%",
        opacity: "0.6",
      },
      "&:hover .css-1nd3ojk-MuiTypography-root-buttonText": {
        color: "#fff",
      },
      "&:hover .css-1sg9l6o-banbutspan": {
        backgroundColor: "#fff",
      },
      [theme.breakpoints.down("mobile")]: {
        width: "100%",
        minWidth: "150px",
        height: "40px",
      },
    },
    buttonText: {
      fontFamily: "League Spartan",
      fontStyle: "normal",
      fontWeight: "500",
      fontSize: "18px",
      lineHeight: "18px",
      letterSpacing: "0.12em",
      textTransform: "uppercase",
      color: "#FFF",
      transition: "all 0.9s",
      [theme.breakpoints.down("mobile")]: {
        fontSize: "14px",
      },
    },
    contitue: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "#141524",
      fontFamily: "League Spartan",
      fontStyle: "normal",
      fontWeight: "500",
      fontSize: "20px",
      lineHeight: "18px",
      marginTop: "24px",
      [`& svg`]: {
        marginLeft: "11px",
      },
      "&:hover": {
        color: "#BD3D3D",
      },
    },
    payOption: {
      display: "flex",
      flexDirection: "column",
      marginTop: "24px",
    },
    payhead: {
      color: "#35364F",
      fontFamily: "League Spartan",
      fontStyle: "normal",
      fontWeight: "400",
      fontSize: "23px",
      lineHeight: "18px",
      marginBottom: "16px",
    },
    payBott: {
      border: "1px solid rgba(214, 214, 214, 0.4)",
      padding: "17px 16px",
    },
    radio: {
      [`& .MuiTypography-root`]: {
        color: "#3D3D47",
        fontFamily: "League Spartan",
        fontStyle: "normal",
        fontWeight: "400",
        fontSize: "18px",
        lineHeight: "20px",
      },
    },
    radiohelper: {
      color: "#858A8C",
      fontFamily: "League Spartan",
      fontStyle: "normal",
      fontWeight: "400",
      fontSize: "15px",
      lineHeight: "18px",
      paddingLeft: "30px",
      marginTop: "-6px",
    },
  };
});

function SubTotalBox(props) {
  const { classes } = useStyles();
  const location = useLocation();
  return (
    <Box component="div" className={classes.subtot}>
      <Typography variant="h4" className={classes.subtotttl}>
        Subtotal:
        <Typography variant="p">₹1800</Typography>
      </Typography>
      <Typography variant="h4" className={classes.subtotttl}>
        Coupon Discount:
        <Typography variant="p">₹100</Typography>
      </Typography>
      <Typography variant="h4" className={classes.subtotttl}>
        Shipping:
        <Typography variant="p">₹98</Typography>
      </Typography>
      <Typography variant="h4" className={classes.subtotal}>
        Total:
        <Typography variant="p">₹1998</Typography>
      </Typography>
      {location?.pathname === "/checkout" && (
        <Box component="div" className={classes.payOption}>
          <Typography variant="h3" className={classes.payhead}>
            Payment Options
          </Typography>
          <Box component="div" className={classes.payBott}>
            <RadioGroup
              aria-labelledby="demo-radio-buttons-group-label"
              defaultValue="Direct bank transfer"
              name="radio-buttons-group"
            >
              <FormControlLabel
                className={classes.radio}
                value="Direct bank transfer"
                control={<Radio />}
                label="Direct bank transfer"
              />
              <FormHelperText className={classes.radiohelper}>
                Make your payment directly into our bank account.
              </FormHelperText>
              <FormControlLabel
                className={classes.radio}
                value="Cash on delivery"
                control={<Radio />}
                label="Cash on delivery"
              />
              <FormControlLabel
                className={classes.radio}
                value="Online UPI"
                control={<Radio />}
                label="Online UPI"
              />
            </RadioGroup>
          </Box>
        </Box>
      )}
      <Box component="div" className={classes.checkButt}>
        <Button
          className={classes.saveButton}
          variant="contained"
          type="submit"
          disableRipple
        >
          <Typography className={classes.buttonText}>
            {props?.button}
          </Typography>
        </Button>
        {location?.pathname === "/cart" && (
          <Box component={Link} className={classes.contitue}>
            Continue Shopping
            <EastIcon />
          </Box>
        )}
      </Box>
    </Box>
  );
}

export default SubTotalBox;
