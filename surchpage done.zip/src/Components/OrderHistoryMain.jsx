import React from "react";
import { makeStyles } from "tss-react/mui";
import {
  Box,
  Typography,
  Grid,
  Autocomplete,
  TextField,
  FormControl,
  Button,
} from "@mui/material";
import { Formik, Field, Form } from "formik";
import { DesktopDatePicker } from "@mui/x-date-pickers/DesktopDatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import ShoppingCartTable from "./ShoppingCartTable";

const useStyles = makeStyles()((theme) => {
  return {
    profileBox: {
      width: "100%",
      marginLeft: "16px",
      padding: "82px 0px 52px 36px!important",
      margin: "0px !important",
      position: "relative",
      "&::before": {
        content: '""',
        position: "absolute",
        width: "100%",
        height: "9px",
        backgroundColor: "#F4F4F4",
        bottom: 0,
        left: "0px",
      },
      [theme.breakpoints.down("laptop")]: {
        padding: "92px 0px 67px 0px !important",
      },
      [theme.breakpoints.down("mobile")]: {
        padding: "74px 0px 32px 0px !important",
      },
    },
    profileHead: {
      fontFamily: "League Spartan",
      fontSize: "25px",
      lineHeight: "23px",
      fontWeight: "500",
      marginBottom: "26px",
    },
    profileGrid: {
      borderBottom: "9px solid #F4F4F4",
      paddingBottom: "40px",
    },
    saveButton: {
      padding: "18px 15px 12px 15px",
      backgroundColor: "#141524",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      borderRadius: "0",
      height: "59px",
      width: "100%",
      position: "relative",
      zIndex: "2",
      overflow: "hidden",
      "&:hover": {
        backgroundColor: "#BD3D3D !important",
      },
      "&::before": {
        content: '""',
        opacity: 0,
        position: "absolute",
        transition: "all 0.85s cubic-bezier(0.68, -0.55, 0.265, 1.55)",
        width: "0%",
        height: "100%",
        background: "#BD3D3D",
        zIndex: "-1",
        top: "-50px",
        "-webkit-transform": "rotate(35deg)",
        transform: "rotate(35deg)",
      },
      "&::after": {
        background: "#fff",
        content: '""',
        opacity: 0,
        position: "absolute",
        top: "-50px",
        "-webkit-transform": "rotate(35deg)",
        transform: "rotate(35deg)",
        transition: "all 3s cubic-bezier(0.19, 1, 0.22, 1)",
        height: "20rem",
        width: "8rem",
        left: "-100%",
      },
      "&:hover::before": {
        left: "120%",
        opacity: "0.5",
      },
      "&:hover::after": {
        left: "200%",
        opacity: "0.6",
      },
      "&:hover .css-1nd3ojk-MuiTypography-root-buttonText": {
        color: "#fff",
      },
      "&:hover .css-1sg9l6o-banbutspan": {
        backgroundColor: "#fff",
      },
      [theme.breakpoints.down("mobile")]: {
        width: "100%",
        minWidth: "150px",
      },
      [theme.breakpoints.down("iph")]: {
        height: "40px",
      },
    },
    buttonText: {
      fontFamily: "League Spartan",
      fontStyle: "normal",
      fontWeight: "500",
      fontSize: "18px",
      lineHeight: "18px",
      letterSpacing: "0.12em",
      textTransform: "uppercase",
      color: "#FFF",
      transition: "all 0.9s",
      [theme.breakpoints.down("mobile")]: {
        fontSize: "14px",
      },
    },
    textField: {
      [`& label`]: {
        fontFamily: "League Spartan !important",
        fontWeight: "400 !important",
        fontSize: "18px !important",
        color: "#7E7F84",
        lineHeight: "30px",
        [theme.breakpoints.down("iph")]: {
          fontSize: "15px !important",
        },
      },
      [`& fieldset`]: {
        borderRadius: 0,
        borderColor: "#7E7F84 !important",
      },
      [`& .css-5tvus1-MuiInputBase-root-MuiOutlinedInput-root`]: {
        fontFamily: "League Spartan !important",
        fontWeight: "400 !important",
        fontSize: "18px !important",
        color: "#7E7F84",
        borderRadius: "0px !important",
        [theme.breakpoints.down("iph")]: {
          fontSize: "15px !important",
        },
      },
      [`& .Mui-error`]: {
        color: "#7E7F84",
        height:"59px"
      },
      [`& .Mui-focused`]: {
        color: "#BD3D3D",
      },
      [`& .Mui-focused .MuiOutlinedInput-notchedOutline`]: {
        borderColor: "#BD3D3D !important",
      },
    },
    cartCont: {
      marginTop: "43px",
      [theme.breakpoints.down("iph")]: {
        marginTop: "25px",
      },
    },
  };
});

const status = [
  {
    name: "Delivered",
  },
  {
    name: "Pending",
  },
  {
    name: "Canceled",
  },
];

const OrderHistoryMain = () => {
  const { classes } = useStyles();
  // let newDate = new Date();
  const [fromDate, setFromDate] = React.useState("");
  const [toDate, setToDate] = React.useState("");

  const handleChange = (newValue) => {
    setFromDate(newValue);
  };
  const handleChange1 = (newValue) => {
    setToDate(newValue);
  };
  const initialValues = {
    status: "",
    from_date: new Date(fromDate),
    to_date: new Date(toDate),
  };
  const onSubmit = async (values, formikHelpers) => {
    console.log("...", values);
  };

  return (
    <Box className={classes.profileBox}>
      <Typography className={classes.profileHead}>Order History</Typography>
      <Formik
        enableReinitialize={true}
        initialValues={initialValues}
        onSubmit={onSubmit}
      >
        {({ values, setFieldValue }) => (
          <Form className={classes.loginForm}>
            <Grid container spacing={2.75}>
              <Grid
                item
                xSmall={12}
                small={12}
                iph={6}
                mobile={4}
                tab={3.5}
                laptop={4}
                desktop={3.5}
              >
                <Field
                  as={Autocomplete}
                  options={status?.map((e) => e?.name)}
                  className={classes.textField}
                  name="state"
                  value={values.status}
                  onChange={(e, newValue) => {
                    setFieldValue("status", newValue);
                  }}
                  renderInput={(params) => (
                    <TextField {...params} label="Status" />
                  )}
                />
              </Grid>
              <Grid
                item
                xSmall={12}
                small={12}
                iph={6}
                mobile={4}
                tab={3}
                laptop={4}
                desktop={3}
              >
                <FormControl fullWidth className={classes.textField}>
                  <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <DesktopDatePicker
                      label="From Date"
                      inputFormat="DD/MM/YYYY"
                      value={fromDate}
                      onChange={handleChange}
                      renderInput={(params) => <TextField {...params} />}
                    />
                  </LocalizationProvider>
                </FormControl>
              </Grid>
              <Grid
                item
                xSmall={12}
                small={12}
                iph={6}
                mobile={4}
                tab={3}
                laptop={4}
                desktop={3}
              >
                <FormControl fullWidth className={classes.textField}>
                  <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <DesktopDatePicker
                      label="To Date"
                      inputFormat="DD/MM/YYYY"
                      value={toDate}
                      onChange={handleChange1}
                      renderInput={(params) => <TextField {...params} />}
                    />
                  </LocalizationProvider>
                </FormControl>
              </Grid>
              <Grid
                item
                xSmall={12}
                small={12}
                iph={6}
                mobile={4}
                tab={2.5}
                laptop={4}
                desktop={2.5}
              >
                <Button
                  className={classes.saveButton}
                  variant="contained"
                  type="submit"
                  disableRipple
                >
                  <Typography className={classes.buttonText}>Search</Typography>
                </Button>
              </Grid>
            </Grid>
          </Form>
        )}
      </Formik>
      <Box component="div" className={classes.cartCont}>
        <ShoppingCartTable />
      </Box>
    </Box>
  );
};

export default OrderHistoryMain;
