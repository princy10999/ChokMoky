import React from "react";
import { makeStyles } from "tss-react/mui";
import { Box, Typography, Grid } from "@mui/material";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import { SimpleInput } from "../Components/Common/SimpleInput";
import StyledButton3 from "./Common/StyledButton3";
import { changePassword } from "../Redux/Actions/AuthUser";
import { useDispatch } from "react-redux";
import swal from "sweetalert";
import { isLoader } from "../Redux/Actions/loaderSlice";

const useStyles = makeStyles()((theme) => {
  return {
    profileBox: {
      width: "100%",
      marginLeft: "16px",
      // marginBottom: "60px",
      // marginTop:"4.3rem",
      padding: "92px 0px 67px 36px!important",
      margin: "0px !important",
      [theme.breakpoints.down("laptop")]: {
        padding: "92px 0px 67px 0px !important",
      },
      [theme.breakpoints.down("mobile")]: {
        padding: "74px 0px 32px 0px !important",
      },
    },
    profileHead: {
      fontFamily: "League Spartan",
      fontSize: "25px",
      lineHeight: "23px",
      fontWeight: "500",
      // marginTop: "30px",
      marginBottom: "30px",
    },
    profileGrid: {
      // borderBottom: "9px solid #F4F4F4",
      paddingBottom: "104px",
      [theme.breakpoints.down("tab")]: {
        paddingBottom: "54px",
      },
    },
    err: {
      color: "#EB222C",
      fontSize: "15px",
    },
    textField: {
      width: "75%",
      [theme.breakpoints.down("tab")]: {
        width: "90%",
      },
      [theme.breakpoints.down("mobile")]: {
        width: "96%",
      },
      [`& label`]: {
        fontFamily: "League Spartan !important",
        fontWeight: "400 !important",
        fontSize: "18px !important",
        color: "#7E7F84",
        lineHeight: "30px",
        [theme.breakpoints.down("iph")]: {
          fontSize: "15px !important",
        },
      },
      [`& fieldset`]: {
        borderRadius: 0,
      },
      [`& .css-5tvus1-MuiInputBase-root-MuiOutlinedInput-root`]: {
        fontFamily: "League Spartan !important",
        fontWeight: "400 !important",
        fontSize: "18px !important",
        color: "#7E7F84",
        borderRadius: "0px !important",
        [theme.breakpoints.down("iph")]: {
          fontSize: "15px !important",
        },
      },
    },
  };
});

const ChangePasswordForm = () => {
  const dispatch = useDispatch();
  const { classes } = useStyles();

  const validationSchema = Yup.object().shape({
    newPassword: Yup.string().required("Please enter your newPassword!"),

    reEnterPassword: Yup.string().required(
      "Please enter your reEnterPassword!"
    ),
    currentPassword: Yup.string().required(
      "Please enter your currentPassword!"
    ),
  });

  const initialValues = {
    newPassword: "",
    reEnterPassword: "",
    currentPassword: "",
  };
  const onSubmit = async (values, formikHelpers) => {
    dispatch(isLoader(true));
    const body = {
      params: {
        old_password: values?.currentPassword,
        new_password: values?.newPassword,
      },
    };
    const data = await dispatch(changePassword(body));
    if (data?.payload?.error) {
      swal({
        title: "Error",
        text: data?.payload?.error?.meaning,
        icon: "error",
      });
    } else if (data?.payload?.result) {
      swal({
        title: "Success",
        text: data?.payload?.result?.status?.meaning,
        icon: "success",
      });
      formikHelpers.resetForm();
    }
    dispatch(isLoader(false));
  };
  return (
    <Box className={classes.profileBox}>
      <Typography className={classes.profileHead}>Change password</Typography>
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={onSubmit}
      >
        {({ values, setFieldValue }) => (
          <Form className={classes.loginForm}>
            <Grid
              container
              className={classes.profileGrid}
              spacing={{
                xSmall: 1,
                laptop: 2,
                smallLaptop: 2,
                desktop: 2,
              }}
              columns={{ xSmall: 4, mobile: 8, tab: 8, laptop: 8 }}
            >
              <Grid item mobile={6} xSmall={4}>
                <Field
                  as={SimpleInput}
                  className={classes.textField}
                  id="currentPassword"
                  label="Current Password"
                  name="currentPassword"
                  marginr="23px"
                  helperText={
                    <Box
                      component="span"
                      className={classes.err}
                      disableGutters
                    >
                      <ErrorMessage name="currentPassword" />
                    </Box>
                  }
                />
              </Grid>
              <Grid item mobile={6} xSmall={4}>
                <Field
                  as={SimpleInput}
                  className={classes.textField}
                  id="newPassword"
                  label="New Password"
                  name="newPassword"
                  helperText={
                    <Box
                      component="span"
                      className={classes.err}
                      disableGutters
                    >
                      <ErrorMessage name="newPassword" />
                    </Box>
                  }
                />
              </Grid>
              <Grid item mobile={6} xSmall={4}>
                <Field
                  as={SimpleInput}
                  className={classes.textField}
                  id="reEnterPassword"
                  label="Re Enter Password"
                  name="reEnterPassword"
                  helperText={
                    <Box
                      component="span"
                      className={classes.err}
                      disableGutters
                    >
                      <ErrorMessage name="reEnterPassword" />
                    </Box>
                  }
                />
              </Grid>
            </Grid>

            <StyledButton3 text="Submit" width="179px" />
          </Form>
        )}
      </Formik>
    </Box>
  );
};

export default ChangePasswordForm;
