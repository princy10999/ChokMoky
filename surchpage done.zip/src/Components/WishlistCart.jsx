import React from "react";
import {
  Box,
  Typography,
  Grid,
} from "@mui/material";
import { makeStyles } from "tss-react/mui";
import Collectioncard from "../Components/Common/Collectioncard";
import LoadButton from "../Components/Common/LoadButton";

const useStyles = makeStyles()((theme) => {
  return {
    buttonDiv: {
      paddingTop: "36px",
      position: "relative",
      display:"flex",
      justifyContent:"center",
      "&::before": {
        content: '""',
        position: "absolute",
        width: "calc(100% + 36px)",
        height: "9px",
        backgroundColor: "#F4F4F4",
        top: 0,
        left: "-36px",
      },
    },
    profileBox: {
      width: "100%",
      marginLeft: "16px",
      // marginBottom: "60px",
      // marginTop:"4.3rem",
      padding: "92px 0px 67px 36px!important",
      margin: "0px !important",
      [theme.breakpoints.down("laptop")]: {
        padding: "92px 0px 67px 0px !important",
      },
      [theme.breakpoints.down("mobile")]: {
        padding: "74px 0px 32px 0px !important",
      },
    },
    profileHead: {
      fontFamily: "League Spartan",
      fontSize: "25px",
      lineHeight: "23px",
      fontWeight: "500",
      // marginTop: "30px",
      marginBottom: "30px",
    },
  };
});
const ArrivalCard = [
  {
    image: require("../Assests/images/wishlist1.png"),
    title: "Silver Diamond Waves Ring",
    description: "Lorem ipsum dolor sit amet consectetur adipiscing elit sed",
    price: " ₹410.00",
    after_discount_price1: " ₹300.00",
  },
  {
    image: require("../Assests/images/wishlist2.png"),
    title: "Oxidised Silver Heart Ring",
    description: "Lorem ipsum dolor sit amet consectetur adipiscing elit sed",
    price: " ₹210.00 ",
    after_discount_price1: "₹180.00",
  },
  {
    image: require("../Assests/images/wishlist3.png"),
    title: "Silver Diamond Waves Ring",
    description: "Lorem ipsum dolor sit amet consectetur adipiscing elit sed",
    price: " ₹410.00",
    after_discount_price1: " ₹300.00",
  },
  {
    image: require("../Assests/images/wishlist4.png"),
    title: "Oxidised Silver Heart Ring",
    description: "Lorem ipsum dolor sit amet consectetur adipiscing elit sed",
    price: " ₹210.00 ",
    after_discount_price1: "₹180.00",
  },
  {
    image: require("../Assests/images/wishlist3.png"),
    title: "Silver Diamond Waves Ring",
    description: "Lorem ipsum dolor sit amet consectetur adipiscing elit sed",
    price: " ₹410.00",
    after_discount_price1: " ₹300.00",
  },
  {
    image: require("../Assests/images/wishlist5.png"),
    title: "Oxidised Silver Heart Ring",
    description: "Lorem ipsum dolor sit amet consectetur adipiscing elit sed",
    price: " ₹210.00 ",
    after_discount_price1: "₹180.00",
  },
];
const WishlistCart = () => {
    const { classes } = useStyles();
  return (
    <Box className={classes.profileBox}>
      <Typography className={classes.profileHead}>Wishlist</Typography>
      <Grid
          container
          spacing={{ xSmall: 2, laptop: 3 }}
          columns={{ xSmall: 4, xTab:12, mobile: 12, laptop: 12 }}
        >
          <Collectioncard
            cardData={ArrivalCard}
            fontSize="21px"
            lineHeight="19.32px"
          />
        </Grid>
        <Box component="div" className={classes.buttonDiv}>
          <LoadButton/>
        </Box>
    </Box>
  );
};

export default WishlistCart;
