import { Box, Container, Typography } from "@mui/material";
import React from "react";
import { useEffect } from "react";
import { makeStyles } from "tss-react/mui";
import abt_ban from "../../Assests/images/abt_ban.png";
import colbg from "../../Assests/images/collect-bg.png";
import artistLeaf from "../../Assests/images/artist-leaf.png";
import Heading from "../../Components/Common/Heading";
import CollectionPolicy from "../../Components/CollectionPolicy";
import Aos from "aos";
import "aos/dist/aos.css";

const useStyles = makeStyles()((theme) => {
  return {
    cont: {
      paddingLeft: "15px",
      paddingRight: "15px",
      height: "100%",
      maxWidth: "1200px",
      [theme.breakpoints.down("laptop")]: {
        maxWidth: "767px",
      },
      [theme.breakpoints.down("mobile")]: {
        maxWidth: "575px",
      },
    },
    abt: {
      position: "relative",
    },
    leaf: {
      position: "absolute",
      top: "1435px",
      right: "0px",
      width: "243px",
      height: "277px",
      zIndex: -1,
      animation: "blow 10s infinite ease-in-out",
      [theme.breakpoints.down("xlDesktop")]: {
        top: "1560px",
      },
      [theme.breakpoints.down("desktop")]: {
        top: "1300px",
      },
      "@keyframes blow": {
        "0%": {
          transform: "rotate(0deg)",
          transformOrigin: "bottom left",
        },
        "25%": {
          transform: "rotate(-3deg)",
          transformOrigin: "bottom left",
        },
        "50%": {
          transform: "rotate(-6deg)",
          transformOrigin: "bottom left",
        },
        "75%": {
          transform: "rotate(-3deg)",
          transformOrigin: "bottom left",
        },
        "100%": {
          transform: "rotate(0deg)",
          transformOrigin: "bottom left",
        },
      },
    },
    ban: {
      position: "relative",
    },
    banimg: {
      width: "100%",
      height: "100%",
      position: "absolute",
      left: "0px",
      right: "0px",
      top: "0px",
      bottom: "0px",
      zIndex: "-1",
      objectFit: "cover",
      objectPosition: "top",
    },
    banTxt: {
      padding: "148px 744px 157px 79px",
      [theme.breakpoints.down("desktop")]: {
        padding: "110px 354px 125px 44px",
      },
      [theme.breakpoints.down("laptop")]: {
        padding: "70px 190px 70px 30px",
      },
      [theme.breakpoints.down("tab")]: {
        padding: "60px 78px 60px 22px",
      },
      [theme.breakpoints.down("iph")]: {
        padding: "36px 8px 30px 8px",
      },
    },
    bantxthead: {
      fontFamily: "Playfair Display",
      fontStyle: "normal",
      fontSize: "59px",
      fontWeight: 700,
      lineHeight: "70px",
      textAlign: "Left",
      verticalAlign: "Top",
      letterSpacing: "2%",
      color: "#FFFFFF",
      marginBottom: "26px",
      [theme.breakpoints.down("laptop")]: {
        fontSize: "52px",
        lineHeight: "62px",
        marginBottom: "12px",
      },
      [theme.breakpoints.down("tab")]: {
        fontSize: "42px",
        lineHeight: "50px",
        marginBottom: "10px",
      },
      [theme.breakpoints.down("mobile")]: {
        lineHeight: "45px",
      },
      [theme.breakpoints.down("iph")]: {
        fontSize: "35px",
        lineHeight: "40px",
        marginBottom: "8px",
      },
      [theme.breakpoints.down("iph")]: {
        fontSize: "30px",
        lineHeight: "33px",
      },
    },
    bantxtp: {
      fontFamily: "League Spartan",
      fontStyle: "Regular",
      fontWeight: 400,
      fontSize: "23px",
      lineHeight: "36px",
      textAlign: "Left",
      verticalAlign: "Top",
      letterSpacing: "3%",
      color: "#FFFFFF",
      [theme.breakpoints.down("laptop")]: {
        fontSize: "20px",
        lineHeight: "28px",
      },
      [theme.breakpoints.down("tab")]: {
        fontSize: "18px",
        lineHeight: "24px",
      },
      [theme.breakpoints.down("mobile")]: {
        fontSize: "16px",
        lineHeight: "18px",
      },
      [theme.breakpoints.down("iph")]: {
        fontSize: "15px",
      }
    },
    story: {
      backgroundImage: `url(${colbg})`,
      backgroundPosition: "top center",
      backgroundRepeat: "no-repeat",
      backgroundSize: "100%",
      backgroundColor: "#FFF8F6",
      padding: "125px 230px 169px",
      position: "relative",
      overflow: "hidden",
      [theme.breakpoints.down("desktop")]: {
        padding: "107px 77px 120px",
      },
      [theme.breakpoints.down("laptop")]: {
        padding: "90px 0px",
      },
      [theme.breakpoints.down("tab")]: {
        padding: "55px 0px",
      },
      [theme.breakpoints.down("iph")]: {
        padding: "42px 0px",
      },
      "&::before": {
        position: "absolute",
        top: 0,
        left: "-20px",
        content: '"Chokmoki"',
        fontFamily: "Playfair Display",
        fontStyle: "Medium",
        fontSize: "157px",
        lineHeight: "130px",
        textAlign: "center",
        verticalAlign: "Top",
        letterSpacing: "-1%",
        color: "rgba(239, 232, 228, 0.31)",
        [theme.breakpoints.down("desktop")]: {
          fontSize: "112px",
          lineHeight: "92px",
        },
        [theme.breakpoints.down("laptop")]: {
          fontSize: "90px",
          lineHeight: "72px",
        },
        [theme.breakpoints.down("tab")]: {
          fontSize: "65px",
          lineHeight: "50px",
        },
        [theme.breakpoints.down("iph")]: {
            fontSize: "45px",
            lineHeight: "35px",
          },
      },
      "&::after": {
        position: "absolute",
        bottom: 0,
        right: "-20px",
        content: '"Jewellery"',
        fontFamily: "Playfair Display",
        fontStyle: "Medium",
        fontSize: "157px",
        lineHeight: "205px",
        textAlign: "center",
        verticalAlign: "Top",
        letterSpacing: "-1%",
        color: "rgba(239, 232, 228, 0.31)",
        [theme.breakpoints.down("desktop")]: {
          fontSize: "112px",
          lineHeight: "135px",
        },
        [theme.breakpoints.down("laptop")]: {
          fontSize: "90px",
          lineHeight: "108px",
        },
        [theme.breakpoints.down("tab")]: {
          fontSize: "65px",
          lineHeight: "75px",
        },
        [theme.breakpoints.down("iph")]: {
            fontSize: "45px",
            lineHeight: "45px",
          },
      },
    },
    desc: {
      marginTop: "84px",
      marginBottom: "26px",
      [theme.breakpoints.down("desktop")]: {
        marginTop: "55px",
      },
    },
    descCont: {
      display: "flex",
      alignItems: "center",
      marginBottom: "95px",
      [theme.breakpoints.down("desktop")]: {
        marginTop: "65px",
      },
      [theme.breakpoints.down("laptop")]: {
        marginTop: "0px",
      },
      [theme.breakpoints.down("mobile")]: {
        flexDirection:"column"
      },
    },
    descimgCont: {
      position: "relative",
      zIndex: "2",
      "&::before": {
        position: "absolute",
        top: "50%",
        left: "50%",
        content: '""',
        width: "549px",
        height: "357px",
        backgroundColor: " rgba(189, 61, 61, 0.07)",
        zIndex: "-1",
        transform: "translate(-50%, -50%)",
        [theme.breakpoints.down("xlDesktop")]: {
          width: "435px",
          height: "334px",
        },
        [theme.breakpoints.down("desktop")]: {
          width: "334px",
          height: "277px",
        },
        [theme.breakpoints.down("laptop")]: {
          width: "270px",
          height: "220px",
        },
      },
    },
    descimg: {
      [theme.breakpoints.down("desktop")]: {
        height: "22em",
        width: "18em",
      },
      [theme.breakpoints.down("laptop")]: {
        height: "18em",
        width: "15em",
      },
    },
    desctext:{
        [theme.breakpoints.down("laptop")]: {
            marginTop:"25px"
          },
    }
  };
});

const abtData = [
  {
    id: "1",
    image: require("../../Assests/images/abtPic1.png"),
    bgText: "T",
    title: "True Unique Styles",
    subtitle:
      "Sed do eiusmod tempor incididunt ut labore et dolore magna. Ut enim ad minim veniam, quis nostrud. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. orem ipsum dolor sit amet, conse elit, sedid do eiusmod tempor incidi ut labore et dolore magna aliqua. Quis ipsum usendi laboris mollit",
    alignT: "left",
    alignI: "flex-start",
    direc: "row",
    marginLeft: "122px",
    marginRight: "auto",
    deskmarginleft: "78px",
    deskmarginRight: "auto",
    tabmarginleft: "35px",
    tabmarginRight: "auto",
    tWidth: "96%",
  },
  {
    id: "2",
    image: require("../../Assests/images/abtPic2.png"),
    bgText: "D",
    title: "Dream of Artist Jewelery",
    subtitle:
      "Sed do eiusmod tempor incididunt ut labore et dolore magna. Ut enim ad minim veniam, quis nostrud. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. orem ipsum dolor sit amet, conse elit, sedid do eiusmod tempor incidi ut labore et dolore magna aliqua. Quis ipsum usendi laboris mollit",
    alignT: "right",
    alignI: "flex-end",
    direc: "row-reverse",
    marginRight: "122px",
    deskmarginRight: "78px",
    deskmarginLeft: "auto",
    tabmarginleft: "auto",
    tabmarginRight: "35px",
    marginLeft: "auto",
    tWidth: "100%",
  },
  {
    id: "3",
    image: require("../../Assests/images/abtPic3.png"),
    bgText: "B",
    title: "Beautiful jewelry accessible to everyone",
    subtitle:
      "Sed do eiusmod tempor incididunt ut labore et dolore magna. Ut enim ad minim veniam, quis nostrud. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. orem ipsum dolor sit amet, conse elit, sedid do eiusmod tempor incidi ut labore et dolore magna aliqua. Quis ipsum usendi laboris mollit",
    alignT: "left",
    alignI: "flex-start",
    direc: "row",
    marginLeft: "122px",
    deskmarginleft: "78px",
    deskmarginRight: "auto",
    tabmarginleft: "35px",
    tabmarginRight: "auto",
    marginRight: "auto",
    tWidth: "100%",
  },
];

function AboutUs() {
  const { classes } = useStyles();
  useEffect(() => {
    Aos.init({ duration: 2000 });
    window.scrollTo({ top: 0, behavior: "smooth" });
    document.title = "About Us - Chokmoki";
  }, []);
  const Descbody = ({ data }) => {
    return (
      <>
        {data.map((item) => (
          <Box
            component="div"
            className={classes.descCont}
            key={item.id}
            sx={{ justifyContent: item.alignI, flexDirection: item.direc }}
          >
            <Box
              component="div"
              className={classes.descimgCont}
              data-aos="fade-up"
            >
              <Box
                component="img"
                src={item.image}
                alt=""
                className={classes.descimg}
              />
            </Box>
            <Box component="div" className={classes.desctext}>
              <Heading
                title={item.title}
                subTitle={item.subtitle}
                bgText={item.bgText}
                fontFamily="Playfair Display"
                size="56px"
                deskSize="52px"
                alignT={item.alignT}
                alignI={item.alignI}
                marginLeft={item.marginLeft}
                deskmarginLeft={item.deskmarginleft}
                deskmarginRight={item.deskmarginRight}
                tabmarginLeft={item.tabmarginleft}
                tabmarginRight={item.tabmarginRight}
                marginRight={item.marginRight}
                aWidth="78.7%"
                letWidth="100%"
                wrap="pre-wrap"
                dis="block"
                tWidth={item.tWidth}
                tabsize="31px"
                iphsize="25px"
                h="210px"
                mobileh="128px"
                mobilebott="152px"
                lapbott="260px"
                lapSize="38px"
                tabbott="245px"
                stabbott="267px"
                tabh="154px"
                bott="168px"
                smallbott="178px"
              />
            </Box>
          </Box>
        ))}
      </>
    );
  };
  return (
    <Box component="div" className={classes.abt}>
      <Box component="img" src={artistLeaf} alt="" className={classes.leaf} />
      <Box component="div" className={classes.ban}>
        <Box component="img" src={abt_ban} alt="" className={classes.banimg} />
        <Box component="div" className={classes.banTxt} data-aos="fade-up">
          <Typography variant="h1" className={classes.bantxthead}>
            Finest Jewelry collections
          </Typography>
          <Typography variant="p" className={classes.bantxtp}>
            In publishing and graphic design, Lorem ipsum is a placeholder text
            commonly used to demonstrate the visual form of a document or a
            typeface without relying on meaningful content.
          </Typography>
        </Box>
      </Box>
      <Box component="div" className={classes.story}>
        <Container className={classes.cont}>
          <Heading
            title="Our Story"
            bgText="O"
            fontFamily="League Spartan, serif"
            subTitle="We don’t just believe in the silver standard, we live by it. What started out as designing jewelry turned into an industry rebellion. And let’s be real, it was necessary."
            size="42px"
            tabsize="40px"
            iphsize="25px"
            h="120px"
            tabh="104px"
            mobilebott="108px"
            iphh="84px"
            tabbott="95px"
            lapbott="98px"
            iphbott="120px"
            bott="80px"
          />
        </Container>
      </Box>
      <Box component="div" className={classes.desc}>
        <Container className={classes.cont}>
          <Descbody data={abtData} />
        </Container>
      </Box>
      <CollectionPolicy />
    </Box>
  );
}

export default AboutUs;
