import React, { useEffect, useState } from "react";
import { makeStyles } from "tss-react/mui";
import { Box, Container, Typography } from "@mui/material";
import Heading from "../../Components/Common/Heading";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import EastIcon from "@mui/icons-material/East";
import CommonCartTable from "../../Components/Common/CommonCartTable";
import ApplyCode from "../../Components/Common/ApplyCode";
import InterestBox from "../../Components/Common/InterestBox";
import SubTotalBox from "../../Components/Common/SubTotalBox";

const useStyles = makeStyles()((theme) => {
  return {
    cont: {
      paddingLeft: "15px",
      paddingRight: "15px",
      height: "100%",
      maxWidth: "1200px",
      [theme.breakpoints.down("laptop")]: {
        maxWidth: "767px",
      },
      [theme.breakpoints.down("mobile")]: {
        maxWidth: "575px",
      },
    },
    cart: {
      margin: "89px auto 97px",
      [theme.breakpoints.down("desktop")]: {
        margin: "70px auto",
      },
      [theme.breakpoints.down("mobile")]: {
        margin: "48px auto",
      },
    },
    breadcrumb: {
      [`& .MuiBreadcrumbs-separator`]: {
        marginLeft: "30px",
        marginRight: "30px",
        [theme.breakpoints.down("desktop")]: {
          marginLeft: "20px",
          marginRight: "20px",
        },
        [theme.breakpoints.down("laptop")]: {
          marginLeft: "10px",
          marginRight: "10px",
        },
        [theme.breakpoints.down("tab")]: {
          marginLeft: "5px",
          marginRight: "5px",
        },
      },
      [`& ol`]: {
        marginTop: "79px",
        justifyContent: "center",
        marginBottom: "37px",
        [theme.breakpoints.down("desktop")]: {
          marginTop: "60px",
        },
        [theme.breakpoints.down("laptop")]: {
          marginTop: "42px",
        },
        [theme.breakpoints.down("tab")]: {
          margin: "30px 0px",
        },
      },
    },
    bredIco: {
      color: "#BABABA",
      width: "26px",
      height: "auto",
      [theme.breakpoints.down("tab")]: {
        width: "18px",
      },
    },
    breadcont: {
      display: "flex",
      justifyContent: "flex-start",
      alignItems: "center",
      fontFamily: "League Spartan",
      fontStyle: "Regular",
      fontSize: "24px",
      lineHeight: "39px",
      TextAlign: "Left",
      verticalAlign: "Top",
      letterSpacing: "3%",
      [theme.breakpoints.down("desktop")]: {
        fontSize: "22px",
        lineHeight: "28px",
      },
      [theme.breakpoints.down("laptop")]: {
        fontSize: "20px",
        lineHeight: "24px",
      },
      [theme.breakpoints.down("tab")]: {
        fontSize: "17px",
        lineHeight: "17px",
      },
    },
    breadnum: {
      width: "37px",
      height: "37px",
      borderRadius: "50%",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      fontFamily: "league spartan",
      fontStyle: "normal",
      fontWeight: "400",
      fontSize: "22px",
      lineHeight: "22px",
      color: "#FFFFFF",
      paddingTop: "4px",
      marginRight: "16px",
      [theme.breakpoints.down("desktop")]: {
        width: "30px",
        height: "30px",
        fontSize: "20px",
        marginRight: "10px",
      },
      [theme.breakpoints.down("laptop")]: {
        width: "23px",
        height: "23px",
        fontSize: "18px",
        marginRight: "6px",
      },
      [theme.breakpoints.down("tab")]: {
        width: "17px",
        height: "17px",
        fontSize: "15px",
        marginRight: "5px",
      },
    },
    cartbott: {
      paddingTop: "14px",
      display: "flex",
      justifyContent: "space-between",
      [theme.breakpoints.down("laptop")]: {
        justifyContent: "flex-start",
        flexDirection: "column",
      },
    },
    cartbottLeft: {
      marginTop: "20px",
      width: "60%",
      [theme.breakpoints.down("laptop")]: {
        width: "98%",
      },
    },
    cartbottRight: {
      width: "30%",
      [theme.breakpoints.down("laptop")]: {
        width: "98%",
      },
    },
    cartleftbott: {
      display: "flex",
      flexDirection: "column",
      marginBottom: "26px",
      marginTop: "34px",
      [theme.breakpoints.down("tab")]: {
        marginBottom: "18px",
        marginTop: "24px",
      },
      [theme.breakpoints.down("mobile")]: {
        marginBottom: "15px",
        marginTop: "18px",
      },
    },
    botthead: {
      color: "#35364F",
      fontSize: "25px",
      fontWeight: 400,
      lineHeight: "18px",
      fontFamily: "League Spartan",
      paddingBottom: "26px",
      [theme.breakpoints.down("tab")]: {
        fontSize: "23px",
        paddingBottom: "18px",
      },
      [theme.breakpoints.down("mobile")]: {
        fontSize: "20px",
        paddingBottom: "12px",
      },
    },
  };
});

function Cart() {
  const { classes } = useStyles();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    document.title = "Shopping Cart - Chokmoki";
  }, []);
  return (
    <Box component="div" className={classes.cart}>
      <Container className={classes.cont}>
        <Heading
          title="Shopping cart"
          bgText="S"
          fontFamily="League Spartan"
          subTitle="Through original imagery and editorial perspectives, we bring you unique point new views."
          size="44px"
          tabsize="44px"
          iphsize="30px"
          h="120px"
          tabh="105px"
          iphh="84px"
          lapbott="65px"
          iphbott="71px"
          tabbott="75px"
          mobilebott="83px"
        />
        <Breadcrumbs
          separator={<EastIcon className={classes.bredIco} />}
          aria-label="breadcrumb"
          className={classes.breadcrumb}
        >
          <Typography className={classes.breadcont} sx={{ color: "#BD3D3D" }}>
            <Box
              component="span"
              className={classes.breadnum}
              sx={{ backgroundColor: "#BD3D3D" }}
            >
              1
            </Box>
            Shopping Cart
          </Typography>
          <Typography className={classes.breadcont} sx={{ color: "#4F5067" }}>
            <Box
              component="span"
              className={classes.breadnum}
              sx={{ backgroundColor: "#4F5067" }}
            >
              2
            </Box>
            Checkout & Delivery Options
          </Typography>
          <Typography className={classes.breadcont} sx={{ color: "#4F5067" }}>
            <Box
              component="span"
              className={classes.breadnum}
              sx={{ backgroundColor: "#4F5067" }}
            >
              3
            </Box>
            Successfully Purchased
          </Typography>
        </Breadcrumbs>
        <CommonCartTable />
        <Box component="div" className={classes.cartbott}>
          <Box component="div" className={classes.cartbottLeft}>
            <ApplyCode />
            <Box component="div" className={classes.cartleftbott}>
              <Typography variant="h2" className={classes.botthead}>
                You may be interested in…
              </Typography>
              <InterestBox />
            </Box>
          </Box>
          <Box component="div" className={classes.cartbottRight}>
            <SubTotalBox button="Proceed to checkout"/>
          </Box>
        </Box>
      </Container>
    </Box>
  );
}

export default Cart;
