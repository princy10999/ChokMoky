import { Container, Box, Grid, TextField } from "@mui/material";
import React, { useEffect } from "react";
import { makeStyles } from "tss-react/mui";
import Heading from "../../Components/Common/Heading";
import enTop from "../../Assests/images/conBg2.png";
import stamp from "../../Assests/images/stamp.png";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import StyledButton2 from "../../Components/Common/StyledButton2";
import { MuiOtpInput } from "mui-one-time-password-input";
import { Typography } from "antd";

const useStyles = makeStyles()((theme) => {
  return {
    contact: {
      margin: "100px 0",
      [theme.breakpoints.down("laptop")]: {
        margin: "75px 0",
      },
      [theme.breakpoints.down("iph")]: {
        margin: "50px 0",
      },
    },
    cont: {
      paddingLeft: "15px",
      paddingRight: "15px",
      height: "100%",
      maxWidth: "1200px",
      [theme.breakpoints.down("laptop")]: {
        maxWidth: "900px",
      },
      [theme.breakpoints.down("tab")]: {
        maxWidth: "700px",
      },
      [theme.breakpoints.down("mobile")]: {
        maxWidth: "575px",
      },
    },
    contactdiv: {
      paddingLeft: "100px",
      paddingRight: "100px",
      [theme.breakpoints.down("desktop")]: {
        paddingLeft: "35px",
        paddingRight: "35px",
      },
      [theme.breakpoints.down("sDesktop")]: {
        paddingLeft: "0px",
        paddingRight: "0px",
      },
    },
    form: {
      // marginTop: "254px",
      marginTop: "236px",
      width: "100%",
      height: "auto",
      maxWidth: "100%",
      maxHeight: "100%",
      background: "#ffe375f0",
      borderTop: "10px solid #ffe375",
      borderLeft: "5px solid #ffe375",
      borderRight: "5px solid #ffe375",
      boxShadow: "0px 0px 23px rgba(0, 0, 0, 0.08)",
      // padding: "41px 35px 47px 35px",
      padding: "25px 25px 30px 25px",
      [theme.breakpoints.down("laptop")]: {
        marginTop: "198px",
        padding: "25px",
      },
      [theme.breakpoints.down("tab")]: {
        marginTop: "154px",
      },
      [theme.breakpoints.down("iph")]: {
        marginTop: "100px",
        padding: "41px 10px 47px 10px",
      },
    },
    enTop: {
      position: "absolute",
      left: "0px",
      top: "17px",
      maxHeight: "100%",
      maxWidth: "100%",
      width: "100%",
      // height: "222px",
      height: "200px",
      transformOrigin: "bottom",
      transform: "translateY(-100%)",
      [theme.breakpoints.down("laptop")]: {
        height: "180px",
      },
      [theme.breakpoints.down("tab")]: {
        height: "142px",
      },
      [theme.breakpoints.down("iph")]: {
        height: "100px",
      },
    },
    enLeft: {
      position: "absolute",
      left: "1px",
      transformOrigin: "right",
      transform: "translateX(-100%)",
      bottom: "0px",
      width: "81px",
      height: "100%",
      backgroundColor: "#ffe375",
      clipPath: "polygon(100% 0, 100% 100%, 0% 89.5%, 0% 10.5%)",
      [theme.breakpoints.down("stab")]: {
        width: "65px",
      },
      [theme.breakpoints.down("tab")]: {
        width: "55px",
      },
      [theme.breakpoints.down("mobile")]: {
        width: "50px",
      },
      [theme.breakpoints.down("iph")]: {
        width: "30px",
      },
    },
    enRight: {
      position: "absolute",
      bottom: "0px",
      right: "1px",
      transformOrigin: "left",
      transform: "translateX(100%)",
      width: "81px",
      height: "100%",
      backgroundColor: "#ffe375",
      clipPath: "polygon(100% 10.5%, 100% 89.5%, 0 100%, 0 0)",
      [theme.breakpoints.down("stab")]: {
        width: "65px",
      },
      [theme.breakpoints.down("tab")]: {
        width: "55px",
      },
      [theme.breakpoints.down("mobile")]: {
        width: "50px",
      },
      [theme.breakpoints.down("iph")]: {
        width: "30px",
      },
    },
    err: {
      color: "#EB222C",
      fontSize: "15px",
    },
    stamp: {
      position: "absolute",
      // top: "36px",
      // right: "36px",
      // width: "91px",
      // height: "109px",
      top: "30px",
      right: "30px",
      width: "80px",
      height: "90px",
      maxHeight: "100%",
      maxWidth: "100%",
      [theme.breakpoints.down("laptop")]: {
        width: "78px",
        height: "82px",
      },
      [theme.breakpoints.down("tab")]: {
        width: "60px",
        height: "60px",
        top: "20px",
        right: "20px",
      },
      [theme.breakpoints.down("iph")]: {
        width: "45px",
        height: "47px",
        top: "15px",
        right: "15px",
      },
    },
    msg: {
      paddingRight: "60px",
      marginTop: "35px",
      [theme.breakpoints.down("laptop")]: {
        paddingRight: "0px",
        marginTop: "24px",
      },
      [theme.breakpoints.down("tab")]: {
        marginTop: "20px",
      },
      [theme.breakpoints.down("iph")]: {
        marginTop: "20px",
      },
      [`& label`]: {
        fontFamily: "League Spartan",
        fontStyle: "normal",
        fontWeight: 400,
        fontSize: "19px",
        lineHeight: "17px",
        letterSpacing: "0.03em",
        color: "#484954",
        [theme.breakpoints.down("tab")]: {
          fontSize: "17px",
        },
        [theme.breakpoints.down("iph")]: {
          fontSize: "16px",
        },
      },
      [`& textarea`]: {
        textAlign: "center",
        [theme.breakpoints.down("laptop")]: {
          height: "135px !important",
        },
        [theme.breakpoints.down("laptop")]: {
          height: "100px !important",
        },
        [theme.breakpoints.down("small")]: {
          height: "70px !important",
        },
        "&::placeholder": {
          fontFamily: "League Spartan",
          fontStyle: "normal",
          fontWeight: 400,
          opacity: 1,
          fontSize: "19px",
          marginTop: "20%",
          lineHeight: "250px",
          letterSpacing: "0.03em",
          color: "#484954",
          [theme.breakpoints.down("laptop")]: {
            marginTop: "60%",
            lineHeight: "100px",
          },
          [theme.breakpoints.down("mobile")]: {
            fontSize: "17px",
          },
          [theme.breakpoints.down("iph")]: {
            fontSize: "16px",
          },
          [theme.breakpoints.down("small")]: {
            marginTop: "60%",
            lineHeight: "70px",
          },
        },
      },
      "& .MuiOutlinedInput-root": {
        borderRadius: "0px !important",
      },
    },
    name: {
      // marginTop: "97px",
      marginTop: "70px",
      [theme.breakpoints.down("laptop")]: {
        marginTop: "60px",
      },
      [theme.breakpoints.down("tab")]: {
        marginTop: "25px",
      },
      [theme.breakpoints.down("iph")]: {
        marginTop: "0px",
      },
      [`& label`]: {
        fontFamily: "League Spartan",
        fontStyle: "normal",
        fontWeight: 400,
        fontSize: "19px",
        lineHeight: "17px",
        letterSpacing: "0.03em",
        color: "#484954",
        [theme.breakpoints.down("tab")]: {
          fontSize: "17px",
        },
        [theme.breakpoints.down("iph")]: {
          fontSize: "16px",
        },
      },
    },
    field: {
      // marginTop: "24px",
      marginTop: "10px",
      [theme.breakpoints.down("laptop")]: {
        marginTop: "8px",
      },
      [theme.breakpoints.down("tab")]: {
        marginTop: "0px",
      },
      [`& label`]: {
        fontFamily: "League Spartan",
        fontStyle: "normal",
        fontWeight: 400,
        fontSize: "19px",
        lineHeight: "17px",
        letterSpacing: "0.03em",
        color: "#484954",
        [theme.breakpoints.down("tab")]: {
          fontSize: "17px",
        },
        [theme.breakpoints.down("iph")]: {
          fontSize: "16px",
        },
      },
    },
    field1: {
      gap: "8px",
      [theme.breakpoints.down("mLaptop")]: {
        gap: "5px",
      },
      [theme.breakpoints.down("laptop")]: {
        gap: "4px",
      },
      [`& label`]: {
        fontFamily: "League Spartan",
        fontStyle: "normal",
        fontWeight: 400,
        fontSize: "19px",
        lineHeight: "17px",
        letterSpacing: "0.03em",
        color: "#484954",
        [theme.breakpoints.down("tab")]: {
          fontSize: "17px",
        },
        [theme.breakpoints.down("iph")]: {
          fontSize: "16px",
        },
        [`& input`]: {
          [theme.breakpoints.down("tab")]: {
            padding: "4px",
          },
        },
      },
      "& .MuiOutlinedInput-root": {
        borderRadius: "0px !important",
        width: "40px",
        height: "43px",
        [theme.breakpoints.down("mLaptop")]: {
          width: "33px",
          height: "38px",
        },
        [theme.breakpoints.down("laptop")]: {
          width: "40px",
          height: "40px",
        },
        [theme.breakpoints.down("stab")]: {
          width: "33px",
          height: "38px",
        },
        [theme.breakpoints.down("tab")]: {
          width: "32px",
          height: "32px",
        },
        [theme.breakpoints.down("mobile")]: {
          width: "26px",
          height: "28px",
        },
        [theme.breakpoints.down("iph")]: {
          width: "19px",
          height: "30px",
        },
      },
      "& .MuiOutlinedInput-input": {
        [theme.breakpoints.down("mobile")]: {
          padding: "10px 6px",
        },
      },
    },
    phone: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      marginTop: "24px",
      flexDirection: "column",
      [theme.breakpoints.down("laptop")]: {
        marginTop: "18px",
      },
      [theme.breakpoints.down("tab")]: {
        marginTop: "12px",
      },
    },
    label: {
      fontFamily: "League Spartan",
      fontStyle: "normal",
      fontWeight: 400,
      fontSize: "19px",
      lineHeight: "17px",
      letterSpacing: "0.03em",
      color: "#484954",
      whiteSpace: "nowrap",
      marginBottom: "10px",
      [theme.breakpoints.down("tab")]: {
        fontSize: "17px",
        marginBottom: "5px",
      },
    },
    butto: {
      // margin: "30px 0 0 auto",
      margin: "20px 0 0 auto",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      width: "50%",
      [theme.breakpoints.down("laptop")]: {
        margin: "25px auto 0",
        width: "80%",
      },
      [theme.breakpoints.down("small")]: {
        margin: "15px auto 0",
        width: "95%",
      },
    },
    enlop: {
      position: "relative",
      margin: "auto",
      [theme.breakpoints.down("xlDesktop")]: {
        width: "90%",
      },
      [theme.breakpoints.down("mLaptop")]: {
        width: "80%",
      },
      [theme.breakpoints.down("iph")]: {
        width: "85%",
      },
    },
    rightgrid: {
      position: "relative",
      "&:before": {
        content: '""',
        position: "absolute",
        width: "1px",
        // height: "360px",
        // top: "34PX",
        height: "329px",
        top: "21PX",
        bottom: "7px",
        left: "-30px",
        backgroundColor: "rgba(0,0,0,0.4)",
        [theme.breakpoints.down("laptop")]: {
          display: "none",
        },
      },
    },
    gridContainer: {
      [theme.breakpoints.down("laptop")]: {
        flexDirection: "column",
      },
      [theme.breakpoints.down("small")]: {
        flexDirection: "column-reverse",
      },
    },
    headP: {
      fontFamily: "Nunito, sans-serif",
      fontSize: "1.2rem",
      textAlign: "center",
      color: "#70717C",
      fontWeight: "400",
      marginTop: "10px",
      lineHeight: "25px",
      [theme.breakpoints.down("tab")]: {
        fontSize: "1.1rem",
        lineHeight: "22px",
      },
      [theme.breakpoints.down("stab")]: {
        fontSize: "1rem",
      },
      [theme.breakpoints.down("iph")]: {
        marginTop: "0",
        fontSize: "15px",
        lineHeight: "18px",
      },
    },
  };
});

function ContactUs() {
  const { classes } = useStyles();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    document.title = "Chokmoki | Contact Us";
  }, []);

  const validationSchema = Yup.object().shape({
    name: Yup.string().required("Please enter your name!"),
    subject: Yup.string().required("Please enter subject!"),
    message: Yup.string().required("Please enter message!"),
    email: Yup.string()
      .email("Please enter a valid email!")
      .required("Please enter your email!"),
    phone: Yup.string()
      .required("Please enter your mobile number!")
      .matches(/^([0-9\s\-+()]*)$/, "Invalid mobile number!")
      .min(10, "Mobile number must be at least 10 characters!")
      .max(10, "Mobile number contains maximum 10 characters!"),
  });

  const initialValues = {
    name: "",
    email: "",
    subject: "",
    phone: "",
    message: "",
  };
  const onSubmit = (values, formikHelpers) => {
    formikHelpers.resetForm();
  };
  return (
    <Box component="div" className={classes.contact}>
      <Container className={classes.cont}>
        <Heading
          title="Contact Us"
          bgText="C"
          fontFamily="Playfair Display, serif"
          subTitle="Through original imagery and editorial perspectives, we bring you unique point newviews."
          size="52px"
          tabsize="36px"
          iphsize="28px"
          h="120px"
          tabh="105px"
          iphh="84px"
          tabbott="77px"
          mobilebott="98px"
          lapbott="67px"
          iphbott="73px"
          smallbott="74px"
          smallsize="24px"
        />
        <Box component="div" className={classes.contactdiv}>
          <Typography className={classes.headP} data-aos="fade-up">
            Plot No 24, Shop No 10, Neelratan Society, Sector 19, Vashi, Navi
            Mumbai
          </Typography>
          <Box component="div" className={classes.enlop}>
            <Box component="img" className={classes.enTop} src={enTop} alt="" />
            <Box component="span" className={classes.enLeft}></Box>
            <Box component="span" className={classes.enRight}></Box>
            <Box component="div" className={classes.form}>
              <Box
                component="img"
                src={stamp}
                alt=""
                className={classes.stamp}
              />
              <Formik
                initialValues={initialValues}
                validationSchema={validationSchema}
                onSubmit={onSubmit}
              >
                {({ values, setFieldValue }) => (
                  <Form className={classes.loginForm}>
                    <Grid container className={classes.gridContainer}>
                      <Grid
                        item
                        xsmall={12}
                        small={12}
                        laptop={6}
                        smallLaptop={6}
                        desktop={6}
                        order={{
                          xsmall: 2,
                          small: 2,
                          laptop: 1,
                          smallLaptop: 1,
                          desktop: 1,
                        }}
                      >
                        <Field
                          as={TextField}
                          multiline
                          rows={12}
                          name="message"
                          id="outlined-basic"
                          // label="Type your message here"
                          placeholder="Type your message here"
                          variant="outlined"
                          fullWidth
                          className={classes.msg}
                          helperText={
                            <Box
                              component="span"
                              className={classes.err}
                              disableGutters
                            >
                              <ErrorMessage name="message" />
                            </Box>
                          }
                        />
                      </Grid>
                      <Grid
                        item
                        xsmall={12}
                        small={12}
                        laptop={6}
                        smallLaptop={6}
                        desktop={6}
                        className={classes.rightgrid}
                        order={{
                          xsmall: 1,
                          small: 1,
                          laptop: 2,
                          smallLaptop: 2,
                          desktop: 2,
                        }}
                      >
                        <Grid
                          container
                          sx={(theme) => ({
                            [theme.breakpoints.down("small")]: {
                              display: "block",
                            },
                          })}
                        >
                          <Grid
                            item
                            xsmall={12}
                            small={12}
                            mobile={12}
                            tab={12}
                            laptop={12}
                            desktop={12}
                          >
                            <Field
                              as={TextField}
                              name="name"
                              label="Name"
                              id="name"
                              variant="standard"
                              fullWidth
                              className={classes.name}
                              helperText={
                                <Box
                                  component="span"
                                  className={classes.err}
                                  disableGutters
                                >
                                  <ErrorMessage name="name" />
                                </Box>
                              }
                            />
                          </Grid>
                          <Grid
                            item
                            xsmall={12}
                            small={12}
                            mobile={12}
                            tab={12}
                            laptop={12}
                            desktop={12}
                          >
                            <Field
                              as={TextField}
                              name="email"
                              label="Email Address"
                              id="email"
                              variant="standard"
                              fullWidth
                              className={classes.field}
                              helperText={
                                <Box
                                  component="span"
                                  className={classes.err}
                                  disableGutters
                                >
                                  <ErrorMessage name="email" />
                                </Box>
                              }
                            />
                          </Grid>
                          <Grid
                            item
                            xsmall={12}
                            small={12}
                            mobile={12}
                            tab={12}
                            laptop={12}
                            desktop={12}
                          >
                            <Field
                              as={TextField}
                              name="subject"
                              label="Subjects"
                              id="subject"
                              variant="standard"
                              fullWidth
                              className={classes.field}
                              helperText={
                                <Box
                                  component="span"
                                  className={classes.err}
                                  disableGutters
                                >
                                  <ErrorMessage name="subject" />
                                </Box>
                              }
                            />
                          </Grid>
                          <Grid
                            item
                            xsmall={12}
                            small={12}
                            mobile={12}
                            tab={12}
                            laptop={12}
                            desktop={12}
                          >
                            <Box className={classes.phone}>
                              <Typography variant="p" className={classes.label}>
                                Phone
                              </Typography>
                              <MuiOtpInput
                                length={10}
                                value={values.phone}
                                name="phone"
                                onChange={(e) => {
                                  setFieldValue("phone", e);
                                }}
                                className={classes.field1}
                              />
                            </Box>
                            <Box
                              component="span"
                              className={classes.err}
                              disableGutters
                            >
                              <ErrorMessage name="phone" />
                            </Box>
                          </Grid>
                        </Grid>
                        {/* <Box component="div" className={classes.butto}>
                        <StyledButton2 text="Send Message" onClick={onSubmit} />
                      </Box> */}
                      </Grid>
                    </Grid>
                    <Box component="div" className={classes.butto}>
                      <StyledButton2 text="Send Message" onClick={onSubmit} />
                    </Box>
                  </Form>
                )}
              </Formik>
            </Box>
          </Box>
        </Box>
      </Container>
    </Box>
  );
}

export default ContactUs;
