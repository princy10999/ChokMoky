import { Divider } from "@mui/material";
import React, { useEffect, useRef } from "react";
import { useState } from "react";
import { useDispatch } from "react-redux";
import ArtistCollection from "../../Components/ArtistCollection";
import BannerPart from "../../Components/BannerPart";
import BestSelling from "../../Components/BestSelling";
import ClientMsg from "../../Components/ClientMsg";
import CollectionPart from "../../Components/CollectionPart";
import CollectionPolicy from "../../Components/CollectionPolicy";
import GetInTouch from "../../Components/GetInTouch";
import NewArrivals from "../../Components/NewArrivals";
import StyleSection from "../../Components/StyleSection";
import { getHomeContent } from "../../Redux/Actions/AuthUser";
import { isLoader } from "../../Redux/Actions/loaderSlice";
import { useAppSelector } from "../../Redux/app/hooks";
function Home() {
  const dispatch = useDispatch();
  const [data, setData] = useState([]);
  const [bannerPath, setBannerPath] = useState();
  const [productPath, setproductPath] = useState();
  const apiCall = async () => {
    dispatch(isLoader(true));
    const getData = await dispatch(getHomeContent());
    setData(getData?.payload?.result?.banner);
    setBannerPath(getData?.payload?.result?.image);
    setproductPath(getData?.payload?.result?.product_image);
    dispatch(isLoader(false));
  };
  useEffect(() => {
    apiCall();
  }, []);
  const ref = useRef(null);
  const handleClick = () => {
    ref.current?.scrollIntoView({ behavior: "smooth" });
  };
  return (
    <>
      <BannerPart
        handleClick={handleClick}
        data={data}
        bannerPath={bannerPath}
        productPath={productPath}
      />
      <div ref={ref}></div>
      <CollectionPart ref={ref} />
      <NewArrivals />
      <StyleSection />
      <ArtistCollection />
      <BestSelling />
      <ClientMsg />
      <Divider />
      <GetInTouch />
      <CollectionPolicy />
    </>
  );
}
export default Home;