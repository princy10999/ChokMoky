import { Box } from "@mui/material";
import React from "react";
import { makeStyles } from "tss-react/mui";
import BestSelling from "../../Components/BestSelling";
import ProductPart from "../../Components/ProductPart";
import CompatibleProduct from "./../../Components/CompatibleProduct";
import SimilarProduct from './../../Components/SimilarProduct';

const useStyles = makeStyles()((theme) => {
  return {
    ProductPage: {
      margin:"116px auto 0 auto",
      paddingLeft: "15px",
      paddingRight: "15px",
      height: "100%",
      maxWidth: "1200px",
      [theme.breakpoints.down("laptop")]: {
        maxWidth: "767px",
        marginTop: "75px",
      },
      [theme.breakpoints.down("tab")]: {
        marginTop: "75px",
      },
      [theme.breakpoints.down("mobile")]: {
        maxWidth: "575px",
        marginTop: "25px",
      },
    },
  };
});

const ProductDetails = () => {
  const { classes } = useStyles();
  return (
    <>
    <Box className={classes.ProductPage}>
      <ProductPart />
      <CompatibleProduct />
    </Box>
    <SimilarProduct/>
    </>
  );
};

export default ProductDetails;
