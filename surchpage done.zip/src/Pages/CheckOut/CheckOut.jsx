import React, { useEffect, useState } from "react";
import { makeStyles } from "tss-react/mui";
import {
  Box,
  Container,
  Typography,
  TextField,
  Autocomplete,
  Grid,
} from "@mui/material";
import Heading from "../../Components/Common/Heading";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import EastIcon from "@mui/icons-material/East";
import CommonCartTable from "../../Components/Common/CommonCartTable";
import SubTotalBox from "../../Components/Common/SubTotalBox";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import { SimpleInput } from "../../Components/Common/SimpleInput";
import Radio from "@mui/material/Radio";
import FormControlLabel from "@mui/material/FormControlLabel";

const useStyles = makeStyles()((theme) => {
  return {
    cont: {
      paddingLeft: "15px",
      paddingRight: "15px",
      height: "100%",
      maxWidth: "1200px",
      [theme.breakpoints.down("laptop")]: {
        maxWidth: "767px",
      },
      [theme.breakpoints.down("mobile")]: {
        maxWidth: "575px",
      },
    },
    cart: {
      margin: "89px auto 97px",
      [theme.breakpoints.down("desktop")]: {
        margin: "70px auto",
      },
      [theme.breakpoints.down("mobile")]: {
        margin: "48px auto",
      },
    },
    breadcrumb: {
      [`& .MuiBreadcrumbs-separator`]: {
        marginLeft: "30px",
        marginRight: "30px",
        [theme.breakpoints.down("desktop")]: {
          marginLeft: "20px",
          marginRight: "20px",
        },
        [theme.breakpoints.down("laptop")]: {
          marginLeft: "10px",
          marginRight: "10px",
        },
        [theme.breakpoints.down("tab")]: {
          marginLeft: "5px",
          marginRight: "5px",
        },
      },
      [`& ol`]: {
        marginTop: "79px",
        justifyContent: "center",
        marginBottom: "37px",
        [theme.breakpoints.down("desktop")]: {
          marginTop: "60px",
        },
        [theme.breakpoints.down("laptop")]: {
          marginTop: "42px",
        },
        [theme.breakpoints.down("tab")]: {
          margin: "30px 0px",
        },
      },
    },
    bredIco: {
      color: "#BABABA",
      width: "26px",
      height: "auto",
      [theme.breakpoints.down("tab")]: {
        width: "18px",
      },
    },
    breadcont: {
      display: "flex",
      justifyContent: "flex-start",
      alignItems: "center",
      fontFamily: "League Spartan",
      fontStyle: "Regular",
      fontSize: "24px",
      lineHeight: "39px",
      TextAlign: "Left",
      verticalAlign: "Top",
      letterSpacing: "3%",
      [theme.breakpoints.down("desktop")]: {
        fontSize: "22px",
        lineHeight: "28px",
      },
      [theme.breakpoints.down("laptop")]: {
        fontSize: "20px",
        lineHeight: "24px",
      },
      [theme.breakpoints.down("tab")]: {
        fontSize: "17px",
        lineHeight: "17px",
      },
    },
    breadnum: {
      width: "37px",
      height: "37px",
      borderRadius: "50%",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      fontFamily: "league spartan",
      fontStyle: "normal",
      fontWeight: "400",
      fontSize: "22px",
      lineHeight: "22px",
      color: "#FFFFFF",
      paddingTop: "4px",
      marginRight: "16px",
      [theme.breakpoints.down("desktop")]: {
        width: "30px",
        height: "30px",
        fontSize: "20px",
        marginRight: "10px",
      },
      [theme.breakpoints.down("laptop")]: {
        width: "23px",
        height: "23px",
        fontSize: "18px",
        marginRight: "6px",
      },
      [theme.breakpoints.down("tab")]: {
        width: "17px",
        height: "17px",
        fontSize: "15px",
        marginRight: "5px",
      },
    },
    cartbott: {
      paddingTop: "14px",
      display: "flex",
      justifyContent: "space-between",
      [theme.breakpoints.down("laptop")]: {
        justifyContent: "flex-start",
        flexDirection: "column",
      },
    },
    cartbottLeft: {
      marginTop: "20px",
      width: "60%",
      [theme.breakpoints.down("laptop")]: {
        width: "98%",
        marginBottom: "16px",
      },
      [theme.breakpoints.down("tab")]: {
        marginTop: "10px",
      },
    },
    cartbottRight: {
      width: "30%",
      [theme.breakpoints.down("laptop")]: {
        width: "98%",
      },
    },
    billHead: {
      fontFamily: "league spartan",
      fontStyle: "normal",
      fontWeight: "400",
      fontSize: "32px",
      lineHeight: "39px",
      color: "#35364F",
      marginBottom: "16px",
      [theme.breakpoints.down("tab")]: {
        fontSize: "26px",
        lineHeight: "30px",
      },
    },
    textField: {
      [`& label`]: {
        fontFamily: "League Spartan !important",
        fontWeight: "400 !important",
        fontSize: "18px !important",
        color: "#7E7F84",
        lineHeight: "30px",
        [theme.breakpoints.down("iph")]: {
          fontSize: "15px !important",
        },
      },
      [`& fieldset`]: {
        borderRadius: 0,
      },
      [`& .css-5tvus1-MuiInputBase-root-MuiOutlinedInput-root`]: {
        fontFamily: "League Spartan !important",
        fontWeight: "400 !important",
        fontSize: "18px !important",
        color: "#7E7F84",
        borderRadius: "0px !important",
        [theme.breakpoints.down("iph")]: {
          fontSize: "15px !important",
        },
      },
      "& input[type=number]": {
        "-moz-appearance": "textfield",
      },
      "& input[type=number]::-webkit-outer-spin-button": {
        "-webkit-appearance": "none",
        margin: 0,
      },
      "& input[type=number]::-webkit-inner-spin-button": {
        "-webkit-appearance": "none",
        margin: 0,
      },
    },
    err: {
      color: "#EB222C",
      fontSize: "15px",
    },
    loginForm: {
      display: "flex",
      justifyContent: "space-between",
      [theme.breakpoints.down("laptop")]: {
        flexDirection: "column",
        justifyContent: "flex-start",
      },
    },
    radio: {
      [`& .MuiTypography-root`]: {
        color: "#3D3D47",
        fontFamily: "League Spartan",
        fontStyle: "normal",
        fontWeight: "400",
        fontSize: "22px",
        lineHeight: "20.5px",
        paddingTop: "5px",
        [theme.breakpoints.down("tab")]: {
          fontSize: "20px",
        },
      },
    },
  };
});
const countries = [
  {
    name: "India",
  },
];
const states = [
  {
    name: "West Bengal",
  },
  {
    name: "Bihar",
  },
  {
    name: "Maharashtra",
  },
  {
    name: "Delhi",
  },
];

function CheckOut() {
  const { classes } = useStyles();
  const initialValues = {
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    region: "",
    country: "",
    postcode: "",
    ship: false,
  };
  const validationSchema = Yup.object().shape({
    first_name: Yup.string().trim().required("Please enter your first name!"),
    last_name: Yup.string().trim().required("Please enter your last name!"),
    email: Yup.string()
      .trim()
      .email("Please enter a valid email address!")
      .required("Please enter email address!"),
    phone: Yup.string()
      .trim()
      .required("Please enter your phone number!")
      .matches(/^([0-9\s\-+()]*)$/, "Invalid phone number!")
      .min(10, "Phone number must be at least 10 characters!")
      .max(10, "Phone number contains maximum 10 characters!"),
    address: Yup.string()
      .trim()
      .required("Please enter your house address!")
      .nullable(),
    city: Yup.string()
      .trim()
      .required("Please enter your town/city!")
      .nullable(),
    state: Yup.string().required("Please select your state!").nullable(),
    country: Yup.string().required("Please select your country!").nullable(),
    postcode: Yup.string()
      .trim()
      .required("Please enter your ZIPCode!")
      .nullable(),
  });
  const onSubmit = async (values, formikHelpers) => {
    console.log("...", values);
  };
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    document.title = "Checkout - Chokmoki";
  }, []);
  return (
    <Box component="div" className={classes.cart}>
      <Container className={classes.cont}>
        <Heading
          title="Checkout"
          bgText="C"
          fontFamily="League Spartan"
          subTitle="Through original imagery and editorial perspectives, we bring you unique point new views."
          size="44px"
          tabsize="44px"
          iphsize="30px"
          h="120px"
          tabh="105px"
          iphh="84px"
          lapbott="80px"
          iphbott="71px"
          tabbott="75px"
          mobilebott="83px"
          bott="57px"
          deskbott="78px"
        />
        <Breadcrumbs
          separator={<EastIcon className={classes.bredIco} />}
          aria-label="breadcrumb"
          className={classes.breadcrumb}
        >
          <Typography className={classes.breadcont} sx={{ color: "#BD3D3D" }}>
            <Box
              component="span"
              className={classes.breadnum}
              sx={{ backgroundColor: "#BD3D3D" }}
            >
              1
            </Box>
            Shopping Cart
          </Typography>
          <Typography className={classes.breadcont} sx={{ color: "#BD3D3D" }}>
            <Box
              component="span"
              className={classes.breadnum}
              sx={{ backgroundColor: "#BD3D3D" }}
            >
              2
            </Box>
            Checkout & Delivery Options
          </Typography>
          <Typography className={classes.breadcont} sx={{ color: "#4F5067" }}>
            <Box
              component="span"
              className={classes.breadnum}
              sx={{ backgroundColor: "#4F5067" }}
            >
              3
            </Box>
            Successfully Purchased
          </Typography>
        </Breadcrumbs>
        <CommonCartTable />
        <Box component="div" className={classes.cartbott}>
          <Formik
            enableReinitialize={true}
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={onSubmit}
          >
            {({ values, setFieldValue }) => (
              <Form className={classes.loginForm}>
                <Box component="div" className={classes.cartbottLeft}>
                  <Box component="div" className={classes.billing}>
                    <Typography variant="h2" className={classes.billHead}>
                      Billing details
                    </Typography>
                    <Grid
                      container
                      className={classes.profileGrid}
                      spacing={{
                        xSmall: 1,
                        laptop: 1.5,
                        smallLaptop: 1.5,
                        desktop: 1.5,
                      }}
                      // columns={{ xSmall: 4, mobile: 8, tab: 8, laptop: 8 }}
                    >
                      <Grid
                        item
                        xSmall={12}
                        small={12}
                        iph={12}
                        mobile={6}
                        tab={3}
                        laptop={6}
                        desktop={6}
                        mLaptop={3}
                      >
                        <Field
                          as={SimpleInput}
                          className={classes.textField}
                          label="First Name"
                          name="first_name"
                          helperText={
                            <Box
                              component="span"
                              className={classes.err}
                              disableGutters
                            >
                              <ErrorMessage name="first_name" />
                            </Box>
                          }
                        />
                      </Grid>
                      <Grid
                        item
                        xSmall={12}
                        small={12}
                        iph={12}
                        mobile={6}
                        tab={3}
                        laptop={6}
                        desktop={6}
                        mLaptop={3}
                      >
                        <Field
                          as={SimpleInput}
                          className={classes.textField}
                          label="Last Name"
                          name="last_name"
                          helperText={
                            <Box
                              component="span"
                              className={classes.err}
                              disableGutters
                            >
                              <ErrorMessage name="last_name" />
                            </Box>
                          }
                        />
                      </Grid>
                      <Grid
                        item
                        xSmall={12}
                        small={12}
                        iph={12}
                        mobile={6}
                        tab={6}
                        laptop={6}
                        desktop={6}
                        mLaptop={6}
                      >
                        <Field
                          as={SimpleInput}
                          className={classes.textField}
                          label="Email Address"
                          name="email"
                          helperText={
                            <Box
                              component="span"
                              className={classes.err}
                              disableGutters
                            >
                              <ErrorMessage name="email" />
                            </Box>
                          }
                        />
                      </Grid>
                      <Grid
                        item
                        xSmall={12}
                        small={12}
                        iph={12}
                        mobile={6}
                        tab={6}
                        laptop={6}
                        desktop={6}
                        mLaptop={6}
                      >
                        <Field
                          as={SimpleInput}
                          className={classes.textField}
                          label="Phone"
                          name="phone"
                          helperText={
                            <Box
                              component="span"
                              className={classes.err}
                              disableGutters
                            >
                              <ErrorMessage name="phone" />
                            </Box>
                          }
                        />
                      </Grid>
                      <Grid
                        item
                        xSmall={12}
                        small={12}
                        iph={12}
                        mobile={12}
                        tab={12}
                        laptop={12}
                        desktop={12}
                        mLaptop={12}
                      >
                        <Field
                          as={SimpleInput}
                          className={classes.textField}
                          label="House Address"
                          name="address"
                          helperText={
                            <Box
                              component="span"
                              className={classes.err}
                              disableGutters
                            >
                              <ErrorMessage name="address" />
                            </Box>
                          }
                        />
                      </Grid>

                      <Grid
                        item
                        xSmall={12}
                        small={12}
                        iph={12}
                        mobile={6}
                        tab={6}
                        laptop={6}
                        desktop={6}
                        mLaptop={6}
                      >
                        <Field
                          className={classes.textField}
                          name="country"
                          as={Autocomplete}
                          options={countries?.map((e) => e?.name)}
                          value={values.country}
                          onChange={(e, newValue) => {
                            setFieldValue("country", newValue);
                          }}
                          renderInput={(params) => (
                            <TextField {...params} label="Country / Region" />
                          )}
                        />
                        <Box
                          component="span"
                          className={classes.err}
                          disableGutters
                        >
                          <ErrorMessage name="country" />
                        </Box>
                      </Grid>
                      <Grid
                        item
                        xSmall={12}
                        small={12}
                        iph={12}
                        mobile={6}
                        tab={6}
                        laptop={6}
                        desktop={6}
                        mLaptop={6}
                      >
                        <Field
                          as={Autocomplete}
                          options={states?.map((e) => e?.name)}
                          className={classes.textField}
                          name="state"
                          value={values.state}
                          onChange={(e, newValue) => {
                            setFieldValue("state", newValue);
                          }}
                          renderInput={(params) => (
                            <TextField {...params} label="State" />
                          )}
                        />
                        <Box
                          component="span"
                          className={classes.err}
                          disableGutters
                        >
                          <ErrorMessage name="state" />
                        </Box>
                      </Grid>
                      <Grid
                        item
                        xSmall={12}
                        small={12}
                        iph={12}
                        mobile={6}
                        tab={6}
                        laptop={6}
                        desktop={6}
                        mLaptop={6}
                      >
                        <Field
                          as={SimpleInput}
                          className={classes.textField}
                          label="Town / City"
                          name="city"
                          helperText={
                            <Box
                              component="span"
                              className={classes.err}
                              disableGutters
                            >
                              <ErrorMessage name="city" />
                            </Box>
                          }
                        />
                      </Grid>
                      <Grid
                        item
                        xSmall={12}
                        small={12}
                        iph={12}
                        mobile={6}
                        tab={6}
                        laptop={6}
                        desktop={6}
                        mLaptop={6}
                      >
                        <Field
                          as={SimpleInput}
                          type="number"
                          showPassword1={true}
                          className={classes.textField}
                          label="ZIP Code"
                          name="postcode"
                          helperText={
                            <Box
                              component="span"
                              className={classes.err}
                              disableGutters
                            >
                              <ErrorMessage name="postcode" />
                            </Box>
                          }
                        />
                      </Grid>
                      <Grid
                        item
                        xSmall={12}
                        small={12}
                        iph={12}
                        mobile={12}
                        tab={12}
                        laptop={12}
                        desktop={12}
                        mLaptop={12}
                      >
                        <Field
                          as={FormControlLabel}
                          value={values.ship}
                          control={<Radio disableRipple />}
                          className={classes.radio}
                          label="Ship to a different address?"
                          name="ship"
                        />
                      </Grid>
                    </Grid>
                  </Box>
                </Box>
                <Box component="div" className={classes.cartbottRight}>
                  <SubTotalBox button="Place order" />
                </Box>
              </Form>
            )}
          </Formik>
        </Box>
      </Container>
    </Box>
  );
}

export default CheckOut;
