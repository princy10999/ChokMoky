import React from "react";
import { makeStyles } from "tss-react/mui";
import { Box, Container, Pagination, Typography } from "@mui/material";
import CollectionHeader from "../../Components/CollectionHeader";
import CollectionData from "../../Components/CollectionData";
import SelectSection from "../../Components/SelectSection";
import {
  getSearchProductResult,
  categoryList,
  subcategoryList,
} from "../../Redux/Actions/AuthUser";
import filter from "../../Assests/images/filter.png";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { useState } from "react";
import { isLoader } from "../../Redux/Actions/loaderSlice";
const useStyles = makeStyles()((theme) => {
  return {
    CollectionSection: {},
    filter: {
      display: "flex",
      justifyContent: "flex-start",
      marginTop: "15px",
    },
    filterimg: {
      width: "14px",
      height: "14px",
      marginRight: "8px",
    },
    filterP: {
      fontFamily: "League Spartan",
      fontStyle: "normal",
      fontWeight: 400,
      fontSize: "18px",
      lineHeight: "18px",
      letterSpacing: "0.01em",
      color: "#BD3D3D",
      cursor: "pointer",
    },
    cont: {
      paddingLeft: "15px",
      paddingRight: "15px",
      height: "100%",
      maxWidth: "1200px",
      [theme.breakpoints.down("laptop")]: {
        maxWidth: "767px",
      },
      [theme.breakpoints.down("mobile")]: {
        maxWidth: "575px",
      },
    },
  };
});
const Search = ({ props }) => {
  const [collection, setcollection] = useState();
  console.log("collection", collection);
  const [minPrice, setMinPrice] = useState("");
  console.log("minPrice", minPrice);
  const [maxPrice, setMaxPrice] = useState("");
  console.log("maxPrice", maxPrice);
  const [categoryListData, setCategoryListData] = useState([]);
  console.log("categoryListData", categoryListData);
  const [subcategoryListData, setSubcategoryListData] = useState([]);
  console.log("subcategoryListData", subcategoryListData);
  const [inputValue, setInputValue] = React.useState("");
  const [category, setCategory] = React.useState("");

  const [inputValue2, setInputValue2] = React.useState("");
  const [value2, setValue2] = React.useState("");
  const [valueRange, setValueRange] = React.useState('');
  const [shortBy, setShortBy] = React.useState('');
  console.log("category", category?.id);
  console.log("value2", value2);
  console.log("valueRange", valueRange);
  console.log("shortBy", shortBy);
  const dispatch = useDispatch();
  const { classes } = useStyles();
  const [open, setOpen] = useState(false);
  const handleOpen = () => {
    setOpen(!open);
  };
  const body = {
    params: {
      keywords: "",
      category: category?.id,
      sub_category: value2?.value,
      max_price: valueRange[1],
      min_price: valueRange[0],
      sort_by: "",
      offset: "",
    },
  };
  console.log("body", body);
  const ArrivalCard = [
    {
      image: require("../../Assests/images/new1.png"),
      head: "Silver Diamond Waves Ring",
      description: "Lorem ipsum dolor sit amet consectetur adipiscing elit sed",
      price: " ₹410.00",
      price2: " ₹300.00",
    },
    {
      image: require("../../Assests/images/new2.png"),
      head: "Oxidised Silver Heart Ring",
      description: "Lorem ipsum dolor sit amet consectetur adipiscing elit sed",
      price: " ₹210.00 ",
      price2: "₹180.00",
    },
    {
      image: require("../../Assests/images/new3.png"),
      head: "Silver Diamond Waves Ring",
      description: "Lorem ipsum dolor sit amet consectetur adipiscing elit sed",
      price: " ₹410.00",
      price2: " ₹300.00",
    },
    {
      image: require("../../Assests/images/new4.png"),
      head: "Oxidised Silver Heart Ring",
      description: "Lorem ipsum dolor sit amet consectetur adipiscing elit sed",
      price: " ₹210.00 ",
      price2: "₹180.00",
    },
    {
      image: require("../../Assests/images/new5.png"),
      head: "Silver Diamond Waves Ring",
      description: "Lorem ipsum dolor sit amet consectetur adipiscing elit sed",
      price: " ₹410.00",
      price2: " ₹300.00",
    },
    {
      image: require("../../Assests/images/new6.png"),
      head: "Oxidised Silver Heart Ring",
      description: "Lorem ipsum dolor sit amet consectetur adipiscing elit sed",
      price: " ₹210.00 ",
      price2: "₹180.00",
    },
    {
      image: require("../../Assests/images/new7.png"),
      head: "Silver Diamond Waves Ring",
      description: "Lorem ipsum dolor sit amet consectetur adipiscing elit sed",
      price: " ₹410.00",
      price2: " ₹300.00",
    },
    {
      image: require("../../Assests/images/new8.png"),
      head: "Oxidised Silver Heart Ring",
      description: "Lorem ipsum dolor sit amet consectetur adipiscing elit sed",
      price: " ₹210.00 ",
      price2: "₹180.00",
    },
    {
      image: require("../../Assests/images/new6.png"),
      head: "Oxidised Silver Heart Ring",
      description: "Lorem ipsum dolor sit amet consectetur adipiscing elit sed",
      price: " ₹210.00 ",
      price2: "₹180.00",
    },
    {
      image: require("../../Assests/images/new7.png"),
      head: "Silver Diamond Waves Ring",
      description: "Lorem ipsum dolor sit amet consectetur adipiscing elit sed",
      price: " ₹410.00",
      price2: " ₹300.00",
    },
    {
      image: require("../../Assests/images/new8.png"),
      head: "Oxidised Silver Heart Ring",
      description: "Lorem ipsum dolor sit amet consectetur adipiscing elit sed",
      price: " ₹210.00 ",
      price2: "₹180.00",
    },
    {
      image: require("../../Assests/images/new6.png"),
      head: "Oxidised Silver Heart Ring",
      description: "Lorem ipsum dolor sit amet consectetur adipiscing elit sed",
      price: " ₹210.00 ",
      price2: "₹180.00",
    },
  ];
  const getSearchProductResultFunction = async () => {
    dispatch(isLoader(true));
    const data = await dispatch(getSearchProductResult(body));
    console.log("data", data);
    setcollection(data?.payload?.details);
    setValueRange([data?.payload?.min_price, data?.payload?.max_price]);
    setMinPrice(+data?.payload?.min_price);
    setMaxPrice(+data?.payload?.max_price);
    dispatch(isLoader(false));
  };
  const selectCategoryFunction = async () => {
    dispatch(isLoader(true));
    const data = await dispatch(categoryList(body));
    setCategoryListData(data?.payload?.result?.category_list);
    dispatch(isLoader(false));
  };
  const selectSubCategoryFunction = async () => {
    if (category?.id) {
      dispatch(isLoader(true));
      const data = await dispatch(
        subcategoryList({
          params: {
            category: category?.id,
          },
        })
      );
      setSubcategoryListData(data?.payload?.result?.subcategory_list);
      dispatch(isLoader(false));
    }
  };
  useEffect(() => {
    getSearchProductResultFunction();
    selectCategoryFunction();

  }, []);
  useEffect(() => {
    selectSubCategoryFunction();

  }, [category?.id]);
  return (
    <Box className={classes.CollectionSection}>
      <CollectionHeader />
      <Container disableGutters className={classes.cont}>
        <Box
          component="div"
          className={classes.filter}
          sx={(theme) => ({
            display: "none !important",
            [theme.breakpoints.down("mobile")]: { display: "block !important" },
          })}
          onClick={() => handleOpen()}
        >
          <Box
            component="img"
            src={filter}
            alt=""
            className={classes.filterimg}
          />
          <Typography variant="p" className={classes.filterP}>
            Filter all Products
          </Typography>
        </Box>
      </Container>
      <Box
        component="div"
        sx={(theme) => ({
          display: "block !important",
          [theme.breakpoints.down("mobile")]: { display: "none !important" },
        })}
      >
        <SelectSection
          m="2rem 9rem 1rem 9rem"
          b="1px solid #D9D9D9"
          desktopm="2rem 7rem 1rem 7rem"
          laptopm="2rem auto 1rem auto"
          open={true}
          categoryListData={categoryListData}
          subcategoryListData={subcategoryListData}
          subCateApi={selectSubCategoryFunction}
          setCategory={setCategory}
          category={category}
          setInputValue={setInputValue}
          inputValue={inputValue}
          setValue2={setValue2}
          value2={value2}
          setInputValue2={setInputValue2}
          inputValue2={inputValue2}
          setValueRange={setValueRange}
          valueRange={valueRange}
          minPrice={minPrice}
          maxPrice={maxPrice}
          shortBy={shortBy}
          setShortBy={setShortBy}
        />
      </Box>
      {open && (
        <Box
          component="div"
          sx={(theme) => ({
            display: "none !important",
            [theme.breakpoints.down("mobile")]: { display: "block !important" },
          })}
        >
          <SelectSection
            m="2rem 9rem 1rem 9rem"
            b="1px solid #D9D9D9"
            desktopm="2rem 7rem 1rem 7rem"
            laptopm="2rem auto 1rem auto"
            open={open}
            categoryListData={categoryListData}
            subcategoryListData={subcategoryListData}
            // subCateApi={selectSubCategoryFunction}
            setCategory={setCategory}
            category={category}
            setInputValue={setInputValue}
            inputValue={inputValue}
            setValue2={setValue2}
            value2={value2}
            setInputValue2={setInputValue2}
            inputValue2={inputValue2}
            setValueRange={setValueRange}
            valueRange={valueRange}
            minPrice={minPrice}
            maxPrice={maxPrice}
            shortBy={shortBy}
            setShortBy={setShortBy}
          />
        </Box>
      )}
      <CollectionData collection={ArrivalCard} />
    </Box>
  );
};
export default Search;