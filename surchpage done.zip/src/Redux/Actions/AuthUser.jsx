import { createAsyncThunk } from "@reduxjs/toolkit";
import { ApiGet, ApiGetNoAuth, ApiPost, ApiPostNoAuth } from "../../Api/Api";
import { api } from "../../Api/AuthApi";
export const dummyAPI = createAsyncThunk("dummyAPI", async (body) => {
  return ApiGetNoAuth(api.dummyAPI)
    .then((res) => {
      return res?.data;
    })
    .catch((err) => err);
});
export const emailVerify = createAsyncThunk("emailVerify", async (body) => {
  return ApiPostNoAuth(api.emailVerify, body)
    .then((res) => {
      return res?.data;
    })
    .catch((err) => err);
});
export const userSignupWithEmail = createAsyncThunk(
  "userSignupWithEmail",
  async (body) => {
    return ApiPostNoAuth(api.userSignupWithEmail, body)
      .then((res) => {
        return res?.data;
      })
      .catch((err) => err);
  }
);
export const userSignupWithMobile = createAsyncThunk(
  "userSignupWithMobile",
  async (body) => {
    return ApiPostNoAuth(api.userSignupWithMobile, body)
      .then((res) => {
        return res?.data;
      })
      .catch((err) => err);
  }
);
export const mobileVerify = createAsyncThunk("mobileVerify", async (body) => {
  return ApiPostNoAuth(api.mobileVerify, body)
    .then((res) => {
      return res?.data;
    })
    .catch((err) => err);
});
export const loginCheack = createAsyncThunk("loginCheack", async (body) => {
  return ApiPostNoAuth(api.loginCheack, body)
    .then((res) => {
      return res?.data;
    })
    .catch((err) => err);
});
export const loginCheackWithOtp = createAsyncThunk("loginCheackWithOtp", async (body) => {
  return ApiPostNoAuth(api.loginCheackWithOtp, body)
    .then((res) => {
      return res?.data;
    })
    .catch((err) => err);
});
export const loginCheackWithEmail = createAsyncThunk(
  "loginCheackWithEmail",
  async (body) => {
    return ApiPostNoAuth(api.loginCheackWithEmail, body)
      .then((res) => {
        return res?.data;
      })
      .catch((err) => err);
  }
);
export const forgetPassword = createAsyncThunk("forgetPassword", async (body) => {
  return ApiPostNoAuth(api.forgetPassword, body)
    .then((res) => {
      return res?.data;
    })
    .catch((err) => err);
});
export const verifyOtp = createAsyncThunk("verifyOtp", async (body) => {
  return ApiPostNoAuth(api.verifyOtp, body)
    .then((res) => {
      return res?.data;
    })
    .catch((err) => err);
});
export const resetPassword = createAsyncThunk("resetPassword", async (body) => {
  return ApiPostNoAuth(api.resetPassword, body)
    .then((res) => {
      return res?.data;
    })
    .catch((err) => err);
});
export const socialLogin = createAsyncThunk("socialLogin", async (body) => {
  return ApiPostNoAuth(api.socialLogin, body)
    .then((res) => {
      return res?.data;
    })
    .catch((err) => err);
});
export const userDetails = createAsyncThunk("userDetails", async (body) => {
  return ApiPost(api.userDetails, body)
    .then((res) => {
      return res?.data;
    })
    .catch((err) => err);
});
export const editProfile = createAsyncThunk("editProfile", async (body) => {
  return ApiPost(api.editProfile, body)
    .then((res) => {
      return res?.data;
    })
    .catch((err) => err);
});

export const emailChangeStatus = createAsyncThunk("emailChangeStatus", async (body) => {
  return ApiGet(api.emailChangeStatus)
    .then((res) => {
      return res?.data;
    })
    .catch((err) => err);
});
export const changePassword = createAsyncThunk("changePassword", async (body) => {
  return ApiPost(api.changePassword, body)
    .then((res) => {
      return res?.data;
    })
    .catch((err) => err);
});
export const getHomeContent = createAsyncThunk("getHomeContent", async (body) => {
  return ApiPost(api.getHomeContent, body)
    .then((res) => {
      return res?.data;
    })
    .catch((err) => err);
});

export const getSearchProductResult = createAsyncThunk("getSearchProductResult", async (body) => {
  return ApiPostNoAuth(api.getSearchProductResult, body)
    .then((res) => {
      return res?.data;
    })
    .catch((err) => err);
});

export const categoryList = createAsyncThunk("categoryList", async (body) => {
  return ApiPostNoAuth(api.categoryList, body)
    .then((res) => {
      return res?.data;
    })
    .catch((err) => err);
});

export const subcategoryList = createAsyncThunk("subcategoryList", async (body) => {
  return ApiPostNoAuth(api.subcategoryList, body)
    .then((res) => {
      return res?.data;
    })
    .catch((err) => err);
});
export const resendOtp = createAsyncThunk("resendOtp", async (body) => {
  return ApiPost(api.resendOtp,body)
    .then((res) => {
      return res?.data;
    })
    .catch((err) => err);
});