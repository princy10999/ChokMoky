import { createSlice, combineReducers } from "@reduxjs/toolkit";
import { dummyAPI, emailChangeStatus, userDetails } from "../Actions/AuthUser";

const initialState = {
    dummyLists: [],
    userDetail: {},
    emailStatus:null,
  };

export let dummyAPISlice = createSlice({
    name: "dummyAPI",
    initialState,
    reducers: {},
    extraReducers: (builder) => {
      builder.addCase(dummyAPI.pending, (state) => {
        state.status = "loading";
      });
      builder.addCase(dummyAPI.fulfilled, (state, { payload }) => {
        state.dummyLists = payload;
        state.status = "success";
      });
      builder.addCase(dummyAPI.rejected, (state, { payload }) => {
        state.dummyLists = payload;
        state.status = "failed";
      });
    },
  });

  
export let userDetailsSlice = createSlice({
    name: "userDetails",
    initialState,
    reducers: {},
    extraReducers: (builder) => {
      builder.addCase(userDetails.pending, (state) => {
        state.status = "loading";
      });
      builder.addCase(userDetails.fulfilled, (state, { payload }) => {
        state.userDetail = payload;
        state.status = "success";
      });
      builder.addCase(userDetails.rejected, (state, { payload }) => {
        state.userDetail = payload;
        state.status = "failed";
      });
    },
  });
export let emailChangeStatusSlice = createSlice({
    name: "emailChangeStatus",
    initialState,
    reducers: {},
    extraReducers: (builder) => {
      builder.addCase(emailChangeStatus.pending, (state) => {
        state.status = "loading";
      });
      builder.addCase(emailChangeStatus.fulfilled, (state, { payload }) => {
        state.emailStatus = payload;
        state.status = "success";
      });
      builder.addCase(emailChangeStatus.rejected, (state, { payload }) => {
        state.emailStatus = payload;
        state.status = "failed";
      });
    },
  });

  
export default combineReducers({
    isDummyApiListData: dummyAPISlice.reducer,
    isUserDetailsData: userDetailsSlice.reducer,
    isEmailChangeStatusData: emailChangeStatusSlice.reducer,
  });